/* Cleanova: duplicate and junk cleaner. Developed by SMAA. Everything runs on the phone. */
(function () {
  'use strict';

  var Cap = window.Capacitor;
  var PL = (Cap && Cap.Plugins) || {};
  var P = (!window.CLEANOVA_MOCK && PL.Cleanova) ? PL.Cleanova : window.CleanovaMock;
  if (!P) {
    if (window.cleanovaDiag) window.cleanovaDiag('native plugin not found. Plugins: ' + Object.keys(PL).join(', '));
    P = new Proxy({}, { get: function () { return function () { return Promise.reject(new Error('plugin missing')); }; } });
  }
  var AppPlugin = (!window.CLEANOVA_MOCK && PL.App) ? PL.App : null;
  var LN = (!window.CLEANOVA_MOCK && PL.LocalNotifications) ? PL.LocalNotifications : null;

  var CL = { views: {} };
  function $(s) { return document.querySelector(s); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function store(k, v) { try { if (v === undefined) { var x = localStorage.getItem('cleanova.' + k); return x === null ? null : JSON.parse(x); } localStorage.setItem('cleanova.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } return null; }

  /* ---------- preferences and language ---------- */
  var PREF = {
    lang: store('lang') || 'both',            /* en | ur | both (Urdu with English caption) */
    theme: store('theme') || 'dark',
    accent: store('accent') || 'teal',
    similar: store('similar') !== false,
    quality: store('quality') !== false,
    keep: store('keep') || 'camera',
    protect: store('protect') || [],
    remind: !!store('remind'),
    trashDays: store('trashDays') || 30
  };
  function T(ur, en) {
    if (PREF.lang === 'en') return en;
    if (PREF.lang === 'ur') return ur;
    return ur + '<small class="e">' + en + '</small>';
  }
  function tt(ur, en) { return PREF.lang === 'en' ? en : ur; }       /* plain text (no markup) */
  function applyLook() {
    var h = document.documentElement;
    var th = PREF.theme === 'auto' ? ((window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) ? 'light' : 'dark') : PREF.theme;
    h.setAttribute('data-theme', th); h.setAttribute('data-accent', PREF.accent);
    h.setAttribute('dir', PREF.lang === 'en' ? 'ltr' : 'rtl');
    h.setAttribute('lang', PREF.lang === 'en' ? 'en' : 'ur');
    document.body.className = PREF.lang === 'en' ? 'en' : '';
    var m = document.querySelector('meta[name=theme-color]'); if (m) m.setAttribute('content', th === 'light' ? '#eef3f8' : '#080e1a');
  }
  function setPref(k, v) { PREF[k] = v; store(k, v); }
  var toastT = 0;
  function toast(ur, en) { var t = $('#toast'); t.innerHTML = T(ur, en); t.hidden = false; clearTimeout(toastT); toastT = setTimeout(function () { t.hidden = true; }, 3200); }
  function fmt(b) {
    if (b >= 1073741824) return (b / 1073741824).toFixed(2) + ' GB';
    if (b >= 1048576) return (b / 1048576).toFixed(b >= 10485760 ? 0 : 1) + ' MB';
    return Math.max(1, Math.round(b / 1024)) + ' KB';
  }
  function nfiles(n) { return T(n + ' فائلیں', n + (n === 1 ? ' file' : ' files')); }

  /* ---------- file helpers ---------- */
  var EXT = {
    img: 'jpg jpeg png webp bmp heic heif gif',
    vid: 'mp4 mkv 3gp mov avi webm',
    aud: 'mp3 m4a aac ogg opus wav amr flac',
    doc: 'pdf doc docx xls xlsx ppt pptx txt csv'
  };
  function ext(p) { var i = p.lastIndexOf('.'); return i < 0 ? '' : p.slice(i + 1).toLowerCase(); }
  function kind(p) { var e = ext(p); for (var k in EXT) if ((' ' + EXT[k] + ' ').indexOf(' ' + e + ' ') >= 0) return k; return 'other'; }
  function base(p) { return p.slice(p.lastIndexOf('/') + 1); }
  function folder(p) { var s = p.replace('/storage/emulated/0/', ''); var i = s.lastIndexOf('/'); return i < 0 ? '/' : s.slice(0, i); }
  function score(it) {
    var p = it.path.toLowerCase(), s = 0;
    if (p.indexOf('/dcim/') >= 0) s += 3;
    if (p.indexOf('/pictures/') >= 0 || p.indexOf('/movies/') >= 0) s += 1;
    if (p.indexOf('/whatsapp') >= 0 || p.indexOf('/telegram') >= 0) s -= 2;
    if (p.indexOf('/download') >= 0) s -= 1;
    if (p.indexOf('screenshot') >= 0) s -= 1;
    var n = base(p);
    if (/\(\d+\)|copy|_copy| - copy/.test(n)) s -= 2;
    return s;
  }
  function best(items, bySize) {
    var l = items.slice().sort(function (a, b) {
      if (PREF.keep === 'oldest' && a.mtime !== b.mtime) return a.mtime - b.mtime;
      if (PREF.keep === 'newest' && a.mtime !== b.mtime) return b.mtime - a.mtime;
      if (PREF.keep === 'largest' && a.size !== b.size) return b.size - a.size;
      var d = score(b) - score(a); if (d) return d;
      if (bySize && b.size !== a.size) return b.size - a.size;
      return a.mtime - b.mtime;
    });
    return l[0];
  }

  /* ---------- state ---------- */
  var S = {
    view: 'life', granted: false, free: 0, total: 0, scanned: false, groups: [], x: { large: [], wa: [], shots: [], junk: [], old: [], blurry: [] }, dirSet: {},
    sel: {}, review: null, list: null, limit: 150, trash: { items: [], bytes: 0 }, trashSel: {}, prog: null, back: [],
    f: { shots: 0, old: 30, blurry: 'all', junk: 'all', waAge: 90, waDir: 'all' }, last: store('last') || null
  };
  var CATS = [
    { id: 'eimg', ur: 'ہو بہو ایک جیسی تصاویر', en: 'Exact photo copies', ic: '🖼' },
    { id: 'simg', ur: 'ملتی جلتی تصاویر (خود دیکھ کر چنیں)', en: 'Similar photos (review each)', ic: '📷' },
    { id: 'evid', ur: 'ویڈیوز', en: 'Videos', ic: '🎬' },
    { id: 'eaud', ur: 'آڈیو', en: 'Audio', ic: '🎵' },
    { id: 'edoc', ur: 'دستاویزات / PDF', en: 'Documents', ic: '📄' },
    { id: 'eoth', ur: 'باقی فائلیں', en: 'Other files', ic: '📦' }
  ];
  function catOf(g) {
    var k = kind(g.items[0].path);
    if (g.type === 'similar') return 'simg';
    return { img: 'eimg', vid: 'evid', aud: 'eaud', doc: 'edoc', other: 'eoth' }[k];
  }
  function catLabel(c) { return T(c.ur, c.en); }

  function prepare(groups, extras) {
    S.groups = groups.map(function (g, i) {
      var keeper = best(g.items, g.type === 'similar');
      return { id: i, type: g.type, size: g.size, items: g.items, keeper: keeper.path, cat: catOf(g) };
    });
    S.sel = {};
    S.groups.forEach(function (g) {
      if (g.type === 'exact') g.items.forEach(function (it) { if (it.path !== g.keeper) S.sel[it.path] = it.size; });
    });
    var x = extras || {};
    S.x = { large: x.large || [], wa: x.wa || [], shots: x.shots || [], junk: (x.junk || []).slice(), old: x.old || [], blurry: x.blurry || [] };
    S.dirSet = {};
    (x.empty || []).forEach(function (d) { S.dirSet[d] = 1; S.x.junk.push({ path: d, size: 0, mtime: 0, dir: true }); });
  }
  function catStats(id) {
    var n = 0, files = 0, bytes = 0, sel = 0, selBytes = 0;
    S.groups.forEach(function (g) {
      if (g.cat !== id) return;
      n++; files += g.items.length;
      g.items.forEach(function (it) { if (it.path !== g.keeper) bytes += it.size; if (S.sel[it.path]) { sel++; selBytes += it.size; } });
    });
    return { groups: n, files: files, bytes: bytes, sel: sel, selBytes: selBytes };
  }
  function selTotals() { var n = 0, b = 0; for (var p in S.sel) { n++; b += S.sel[p]; } return { n: n, b: b }; }
  function sumItems(l) { var b = 0; l.forEach(function (i) { b += i.size; }); return b; }
  function dupBytes() { var b = 0; S.groups.forEach(function (g) { g.items.forEach(function (it) { if (it.path !== g.keeper) b += it.size; }); }); return b; }
  /* easy wins: duplicate extras + junk + blurry + old screenshots, each file counted once */
  function potential() {
    var seen = {}, b = 0;
    function add(p, s) { if (!seen[p]) { seen[p] = 1; b += s; } }
    S.groups.forEach(function (g) { if (g.type === 'exact') g.items.forEach(function (it) { if (it.path !== g.keeper) add(it.path, it.size); }); });
    S.x.junk.forEach(function (i) { add(i.path, i.size); });
    S.x.blurry.forEach(function (i) { add(i.path, i.size); });
    S.x.shots.forEach(function (i) { if (Date.now() - i.mtime > 30 * 864e5) add(i.path, i.size); });
    return b;
  }
  function savePotential() { S.last = { b: potential(), t: Date.now() }; store('last', S.last); }

  /* ---------- extra lists ---------- */
  var DAY = 864e5;
  function older(it, days) { return !days || (Date.now() - it.mtime) > days * DAY; }
  function waType(it) {
    var p = it.path.toLowerCase();
    if (p.indexOf('voice notes') >= 0) return 'voice';
    return kind(it.path);
  }
  var WA_TYPES = [
    { id: 'img', ur: 'تصاویر', en: 'Images', ic: '🖼' }, { id: 'vid', ur: 'ویڈیوز', en: 'Videos', ic: '🎬' },
    { id: 'voice', ur: 'وائس نوٹس', en: 'Voice notes', ic: '🎙' }, { id: 'aud', ur: 'آڈیو', en: 'Audio', ic: '🎵' },
    { id: 'doc', ur: 'دستاویزات', en: 'Documents', ic: '📄' }, { id: 'other', ur: 'باقی', en: 'Other', ic: '📦' }
  ];
  function waFiltered() {
    return S.x.wa.filter(function (it) {
      if (!older(it, S.f.waAge)) return false;
      var sent = it.path.indexOf('/Sent/') >= 0;
      if (S.f.waDir === 'sent' && !sent) return false;
      if (S.f.waDir === 'recv' && sent) return false;
      return true;
    });
  }
  var AGE_OPTS = function (key) { return { key: key, opts: [[30, '1 ماہ سے پرانی', 'Over 1 month'], [90, '3 ماہ سے پرانی', 'Over 3 months'], [180, '6 ماہ سے پرانی', 'Over 6 months']] }; };
  function listDef(id) {
    var d;
    if (id === 'large') d = { ur: 'بڑی فائلیں', en: 'Large files', hint: ['50 MB سے بڑی فائلیں، سب سے بڑی پہلے۔ خود دیکھ کر چنیں۔', 'Files over 50 MB, biggest first. Pick what you do not need.'], items: S.x.large.slice(), chips: [] };
    else if (id === 'shots') d = { ur: 'اسکرین شاٹس', en: 'Screenshots', hint: ['پرانے اسکرین شاٹس جو شاید اب کام کے نہیں۔', 'Old screenshots you probably do not need.'], items: S.x.shots.filter(function (i) { return older(i, S.f.shots); }), chips: [{ key: 'shots', opts: [[0, 'سب', 'All'], [30, '1 ماہ سے پرانے', 'Over 1 month'], [90, '3 ماہ سے پرانے', 'Over 3 months']] }] };
    else if (id === 'blurry') d = { ur: 'دھندلی اور تاریک تصاویر', en: 'Blurry and dark photos', hint: ['سافٹ ویئر کا اندازہ ہے، غلط بھی ہو سکتا ہے۔ ہر تصویر خود دیکھ کر چنیں۔', 'This is an automatic guess and can be wrong. Check each photo.'], items: S.x.blurry.filter(function (i) { return S.f.blurry === 'all' || i.reason === S.f.blurry; }), chips: [{ key: 'blurry', opts: [['all', 'سب', 'All'], ['blur', 'دھندلی', 'Blurry'], ['dark', 'تاریک', 'Dark']] }] };
    else if (id === 'junk') d = { ur: 'فالتو فائلیں', en: 'Junk files', hint: ['پرانی انسٹالر APK، عارضی فائلیں اور خالی فولڈر۔', 'Old installer APKs, temporary files and empty folders.'], items: S.x.junk.filter(function (i) { var e = ext(i.path), f = S.f.junk; return f === 'all' || (f === 'apk' && e === 'apk' && !i.dir) || (f === 'dir' && i.dir) || (f === 'tmp' && e !== 'apk' && !i.dir); }), chips: [{ key: 'junk', opts: [['all', 'سب', 'All'], ['apk', 'APK', 'APK'], ['tmp', 'عارضی', 'Temp'], ['dir', 'خالی فولڈر', 'Empty folders']] }] };
    else if (id === 'old') d = { ur: 'پرانی ڈاؤن لوڈز', en: 'Old downloads', hint: ['Download فولڈر کی پرانی فائلیں۔', 'Old files in your Download folder.'], items: S.x.old.filter(function (i) { return older(i, S.f.old); }), chips: [AGE_OPTS('old')] };
    else if (id.indexOf('wa:') === 0) {
      var t = id.slice(3), wt = WA_TYPES.filter(function (x) { return x.id === t; })[0];
      d = { ur: 'واٹس ایپ · ' + wt.ur, en: 'WhatsApp · ' + wt.en, hint: ['واٹس ایپ کا پرانا میڈیا۔ ہٹانے سے چیٹ کا متن نہیں جاتا۔', 'Old WhatsApp media. Chat text is not touched.'], items: waFiltered().filter(function (i) { return waType(i) === t; }), chips: [AGE_OPTS('waAge'), { key: 'waDir', opts: [['all', 'سب', 'All'], ['recv', 'موصول شدہ', 'Received'], ['sent', 'بھیجی ہوئی', 'Sent']] }] };
    }
    d.items.sort(function (a, b) { return (b.dir ? -1 : 0) - (a.dir ? -1 : 0) || b.size - a.size; });
    d.id = id;
    return d;
  }

  /* ---------- thumbnails ---------- */
  var thumbCache = {}, thumbQ = [], thumbBusy = 0;
  function pumpThumbs() {
    while (thumbBusy < 2 && thumbQ.length) {
      var job = thumbQ.shift(); thumbBusy++;
      (function (j) {
        P.thumbnail({ path: j.path, size: 160 }).then(function (r) { thumbCache[j.path] = (r && r.data) || ''; j.cb(thumbCache[j.path]); }).catch(function () { thumbCache[j.path] = ''; }).then(function () { thumbBusy--; pumpThumbs(); });
      })(job);
    }
  }
  var io = null;
  function watchThumbs(root) {
    if (!io && window.IntersectionObserver) io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        var el = e.target; io.unobserve(el);
        var path = el.getAttribute('data-p');
        if (thumbCache[path] !== undefined) { if (thumbCache[path]) { el.style.backgroundImage = 'url(' + thumbCache[path] + ')'; el.textContent = ''; } return; }
        thumbQ.push({ path: path, cb: function (d) { if (d) { el.style.backgroundImage = 'url(' + d + ')'; el.textContent = ''; } } }); pumpThumbs();
      });
    }, { root: $('#body'), rootMargin: '300px' });
    [].forEach.call(root.querySelectorAll('.im[data-p]'), function (el) { if (io) io.observe(el); });
  }

  /* ---------- navigation ---------- */
  var IC = {
    chat: '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    route: '<circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="5" r="2.5"/><path d="M8.5 19H16a3.5 3.5 0 0 0 0-7H8a3.5 3.5 0 0 1 0-7h7.5"/>',
    heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
    sl: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    spark: '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
    phone: '<rect x="5" y="2" width="14" height="20" rx="3"/><line x1="12" y1="18" x2="12.01" y2="18"/>',
    card: '<rect x="2" y="5" width="20" height="14" rx="3"/><line x1="2" y1="10" x2="22" y2="10"/>',
    drop: '<path d="M12 2.7l5.7 5.7a8 8 0 1 1-11.4 0z"/>',
    bat: '<rect x="2" y="7" width="17" height="10" rx="2.5"/><line x1="22" y1="11" x2="22" y2="13"/>',
    hdd: '<path d="M22 12H2"/><path d="M5.5 5.1L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.7 4H7.3a2 2 0 0 0-1.8 1.1z"/>',
    pulse: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    pill: '<rect x="2.5" y="8.5" width="19" height="7" rx="3.5" transform="rotate(-35 12 12)"/><line x1="9" y1="9" x2="15" y2="15"/>',
    flame: '<path d="M12 22c4 0 7-2.8 7-7 0-4-3-6-4-10-3 2-4 4-4.5 6-1-1-1.5-2-1.5-3-2 2-4 4-4 7 0 4.2 3 7 7 7z"/>',
    arr: '<path d="M7 17L17 7M8 7h9v9"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/>',
    scale: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 9a4 4 0 0 1 8 0"/><line x1="12" y1="9" x2="13.5" y2="6.5"/>',
    food: '<path d="M4 3v7a3 3 0 0 0 3 3v8"/><path d="M7 3v7"/><path d="M10 3v7a3 3 0 0 1-3 3"/><path d="M17 3c-2 2-3 5-3 8h3v10"/>',
    id: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="11" r="2.2"/><path d="M5.5 17c.6-2 2-3 3.5-3s2.9 1 3.5 3"/><line x1="15" y1="10" x2="19" y2="10"/><line x1="15" y1="14" x2="18" y2="14"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
    phoneCall: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    news: '<path d="M4 4h13a2 2 0 0 1 2 2v13a1 1 0 0 0 1 1H6a2 2 0 0 1-2-2z"/><path d="M19 8h2v11a1 1 0 0 1-1 1"/><line x1="8" y1="8" x2="15" y2="8"/><line x1="8" y1="12" x2="15" y2="12"/><line x1="8" y1="16" x2="12" y2="16"/>',
    tv: '<rect x="2" y="5" width="20" height="14" rx="2"/><polyline points="8 2 12 5 16 2"/>'
  };
  function ico(n, cls) { return '<svg class="i ' + (cls || '') + '" viewBox="0 0 24 24">' + (IC[n] || '') + '</svg>'; }
  var TABS = [
    { id: 'life', ic: ico('home'), ur: 'ہوم', en: 'Home' }, { id: 'chat', ic: ico('chat'), ur: 'چیٹ', en: 'Chat' },
    { id: 'health', ic: ico('heart'), ur: 'صحت', en: 'Health' }, { id: 'news', ic: ico('news'), ur: 'خبریں', en: 'News' }, { id: 'home', ic: ico('grid'), ur: 'ٹولز', en: 'Tools' }, { id: 'days', ic: ico('route'), ur: 'سفرنامہ', en: 'Travel' }
  ];
  var TAB_OF = { life: 'life', home: 'home', overview: 'home', dups: 'home', review: 'home', list: 'home', wa: 'home', trash: 'home', settings: 'life', chat: 'chat', chatroom: 'chat', done: 'home', contacts: 'home', monitor: 'home', trips: 'days', trip: 'days', days: 'days', day: 'days' };
  function go(view, extra) { S.back.push({ view: S.view, review: S.review, list: S.list }); S.view = view; if (extra !== undefined) { if (view === 'review') S.review = extra; else S.list = extra; } S.limit = 150; render(); }
  function goBack() {
    if (!$('#modal').hidden) { $('#modal').hidden = true; return true; }
    if (S.view === 'scanning') { S.back = []; S.view = 'home'; render(); toast('اسکین پس منظر میں چل رہا ہے', 'Scan keeps running in the background'); return true; }
    if (S.view === 'gate') { S.view = 'life'; S.back = []; render(); return true; }
    if (S.view === 'life' && !S.back.length) return false;
    var b = S.back.pop() || { view: 'life' };
    S.view = b.view; S.review = b.review; S.list = b.list; render(); return true;
  }
  var lastBack = 0, WEB = (Cap && Cap.Plugins && Cap.Plugins.Web) ? Cap.Plugins.Web : null;
  CL.webOpen = false;
  if (WEB && WEB.addListener) WEB.addListener('closed', function () { CL.webOpen = false; });
  try { if (AppPlugin && AppPlugin.addListener) AppPlugin.addListener('backButton', function () {
    if (CL.webOpen && WEB) { WEB.back().then(function (r) { if (r && r.open === false) CL.webOpen = false; }); return; }
    if (goBack()) return;
    if (Date.now() - lastBack < 2200) AppPlugin.exitApp(); else { lastBack = Date.now(); toast('بند کرنے کے لیے دوبارہ بیک دبائیں', 'Press back again to exit'); }
  }); } catch (e) { /* back button stays default */ }

  /* ---------- chrome ---------- */
  function langToggle() {
    return '<div class="lang"><button data-l="en" class="' + (PREF.lang === 'en' ? 'on' : '') + '">EN</button><button data-l="ur" class="' + (PREF.lang !== 'en' ? 'on' : '') + '">اردو</button></div>';
  }
  function setTop(titleHtml) {
    $('#title').innerHTML = titleHtml;
    $('#topact').innerHTML = '<button class="gearb" id="gearb" aria-label="settings">' + ico('gear') + '</button>' + langToggle();
    var gb = document.getElementById('gearb'); if (gb) gb.onclick = function () { if (S.view !== 'settings') go('settings'); };
    [].forEach.call(document.querySelectorAll('#topact [data-l]'), function (b) {
      b.onclick = function () { var l = b.dataset.l; if (l === 'en') setPref('lang', 'en'); else if (PREF.lang === 'en') setPref('lang', 'both'); applyLook(); render(); };
    });
  }
  function setBottom(html) { var b = $('#action'); b.hidden = !html; b.innerHTML = html || ''; }
  function setNav(on) {
    var n = $('#nav'); n.hidden = !on; if (!on) return;
    var cur = TAB_OF[S.view];
    n.innerHTML = (CL.navFilter ? TABS.filter(CL.navFilter) : TABS).map(function (t) { return '<button data-tab="' + t.id + '" class="' + (t.id === cur ? 'on' : '') + '"><i>' + t.ic + (t.id === 'chat' && CL.chatUnread ? (function () { var u = CL.chatUnread(); return u ? '<b class="nbadge">' + (u > 9 ? '9+' : u) + '</b>' : ''; })() : '') + '</i>' + (PREF.lang === 'en' ? t.en : t.ur) + '</button>'; }).join('');
    [].forEach.call(n.querySelectorAll('[data-tab]'), function (b) {
      b.onclick = function () {
        var id = b.dataset.tab; S.back = [];
        if (id === 'days') S.dl = null;
        S.view = id; render();
      };
    });
  }
  function moveBar() {
    var t = selTotals();
    if (!t.n) return setBottom('');
    setBottom('<button class="btn" id="movebtn">' + T('ٹریش میں بھیجیں (' + t.n + ' · ' + fmt(t.b) + ')', 'Move selected to trash (' + t.n + ' · ' + fmt(t.b) + ')') + '</button>');
    $('#movebtn').onclick = confirmMove;
  }
  function footer() { return '<div class="foot">' + tt('سب کچھ آپ کے فون میں ہوتا ہے، کچھ اپلوڈ نہیں ہوتا۔', 'Everything stays on your phone. Nothing is uploaded.') + '<br>Developed by <b>SMAA</b></div>'; }

  function render() {
    if (S.view === 'home' && !S.granted) S.view = 'gate';
    var fn = (CL.views[S.view]) || { gate: vGate, home: vHome, scanning: vScan, overview: vOverview, dups: vDups, review: vReview, list: vList, wa: vWa, trash: vTrash, settings: vSettings, done: vDone, contacts: vContacts, monitor: vMonitor, trips: vTrips, trip: vTrip, days: vDays, day: vDay }[S.view] || vHome;
    if (S.view !== 'monitor') clearMon();
    if (S.view !== 'trips') clearTrip();
    if (S.view !== 'days') clearDays();
    $('#body').scrollTop = 0;
    $('#body').onclick = null;
    setNav(S.view !== 'gate' && S.view !== 'scanning');
    setBottom('');
    fn();
    topBack();
  }
  /* on-screen back button on every inner screen (the same as the phone's back key) */
  function topBack() {
    var old = document.getElementById('tbk'); if (old) old.remove();
    if (!S.back.length || S.view === 'gate') return;
    var top = document.querySelector('.top'); if (!top) return;
    var b = document.createElement('button'); b.id = 'tbk'; b.className = 'tbk'; b.setAttribute('aria-label', 'back');
    b.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" style="' + (PREF.lang === 'en' ? '' : 'transform:scaleX(-1)') + '"><polyline points="15 18 9 12 15 6"/></svg>';
    b.onclick = function () { goBack(); };
    top.insertBefore(b, top.firstChild);
  }

  function needScan() {
    $('#body').innerHTML = '<div class="card center"><div style="font-size:50px">🔍</div><h2 style="font-size:20px">' + T('پہلے اسکین کریں', 'Scan first') + '</h2><p class="mut">' + tt('فون اسکین کرنے کے بعد یہاں نتیجہ نظر آئے گا۔', 'The result will appear here after a scan.') + '</p><button class="btn" id="scanhere">' + T('فون اسکین کریں', 'Scan my phone') + '</button></div>' + footer();
    $('#scanhere').onclick = chooseScan;
  }

  /* ---------- screens ---------- */
  function vGate() {
    setTop(T('کلینووا', 'Cleanova')); setNav(false);
    $('#body').innerHTML = '<div class="card center"><div style="font-size:54px">🔒</div><h2 style="font-size:22px">' + T('اجازت درکار ہے', 'Permission needed') + '</h2>' +
      '<p class="mut" style="margin-top:8px">' + tt('فائلیں ڈھونڈنے اور صاف کرنے کے لیے کلینووا کو فون کی فائلیں دیکھنے کی اجازت چاہیے۔ سب کچھ آپ کے فون میں ہی رہتا ہے، کچھ اپلوڈ نہیں ہوتا۔', 'Cleanova needs access to your files to find and clean them. Everything stays on your phone; nothing is uploaded.') + '</p>' +
      '<button class="btn" id="allow">' + T('اجازت دیں', 'Allow access') + '</button>' +
      '<p class="mut" style="margin-top:12px">' + tt('کھلنے والی سکرین میں Cleanova کو آن کریں، پھر واپس آ جائیں۔', 'Turn Cleanova on in the screen that opens, then come back.') + '</p></div>' + footer();
    $('#allow').onclick = function () { P.requestAccess().then(function (r) { if (r && r.granted) refreshStatus(); }).catch(function () { /* user will return */ }); };
  }

  function ring(pct) {
    var dash = Math.max(2, Math.min(100, pct)) * 0.97;
    return '<div class="ring"><svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--line)" stroke-width="3.4"/><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--acc)" stroke-width="3.4" stroke-linecap="round" stroke-dasharray="' + dash + ' 100"/></svg><div>' + pct + '%<small>' + tt('استعمال', 'used') + '</small></div></div>';
  }
  function tile(id, ic, ur, en, sub, size) {
    var cap = PREF.lang === 'en' ? sub[1] : (PREF.lang === 'ur' ? sub[0] : en);
    return '<button class="tool" data-open="' + id + '"><div class="ic">' + ic + '</div>' + (size ? '<span class="sz">' + size + '</span>' : '') + '<b>' + (PREF.lang === 'en' ? en : ur) + '</b><small class="e" style="display:block">' + cap + '</small></button>';
  }
  function openTool(id) {
    if (id === 'contacts') { S.ct = { st: 'init', groups: [], sel: {}, act: 'merge' }; go('contacts'); return; }
    if (id === 'days') { S.dl = null; go('days'); return; }
    if (id === 'trips') { S.tr = null; go('trips'); return; }
    if (id === 'monitor') { S.mon = null; go('monitor'); return; }
    if (id === 'trash') { loadTrash().then(function () { S.back = []; go('trash'); }); return; }
    if (!S.scanned) { go(id === 'dups' ? 'dups' : (id === 'wa' ? 'wa' : 'list'), id === 'dups' || id === 'wa' ? undefined : id); return; }
    if (id === 'dups') go('dups'); else if (id === 'wa') go('wa'); else go('list', id);
  }

  function vHome() {
    setTop(T('ٹولز', 'Tools'));
    var used = S.total ? Math.round((S.total - S.free) / S.total * 100) : 0;
    var pot = S.scanned ? potential() : (S.last ? S.last.b : null);
    var hero = '<div class="hero">' + ring(used) + '<div><div class="k">' + (pot === null ? T('اسکین کر کے دیکھیں', 'Scan to see how much you can free') : T('آپ خالی کر سکتے ہیں', 'You can free up to')) + '</div>' + (pot === null ? '' : '<div class="big">' + fmt(pot) + '</div>') + '<div class="k" style="font-size:12.5px">' + tt(fmt(S.free) + ' خالی · کل ' + fmt(S.total), fmt(S.free) + ' free of ' + fmt(S.total)) + '</div></div></div>';
    var sz = function (b) { return S.scanned && b ? fmt(b) : ''; };
    var sub = {
      dups: ['ایک جیسی اور ملتی جلتی', 'Exact and similar'], large: ['سب سے بڑی پہلے', 'Biggest first'], wa: ['پرانا میڈیا', 'Old media'], shots: ['عمر کے لحاظ سے', 'By age'],
      blurry: ['خود دیکھ کر چنیں', 'Review each'], junk: ['خالی فولڈر، APK', 'Empty folders, APKs'], old: ['Download کی پرانی فائلیں', 'Old downloads folder'], trash: ['واپس لانے کے لیے', 'Undo and restore'], contacts: ['ایک جیسے نمبر والے', 'Same numbers or names']
    };
    $('#body').innerHTML = hero + scanBanner() +
      '<button class="btn" id="scanbtn">' + T('فون اسکین کریں', 'Scan my phone') + '<small class="e">' + tt('ڈپلیکیٹ، کچرا اور بڑی فائلیں ڈھونڈیں', 'Finds duplicates, junk and big files') + '</small></button>' +
      '<div class="sec">' + tt('صفائی کے اوزار', 'CLEAN-UP TOOLS') + '</div><div class="grid">' +
      tile('dups', '🖼', 'ڈپلیکیٹ فائلیں', 'Duplicates', sub.dups, sz(dupBytes())) +
      tile('large', '📦', 'بڑی فائلیں', 'Large files', sub.large, sz(sumItems(S.x.large))) +
      tile('wa', '💬', 'واٹس ایپ', 'WhatsApp', sub.wa, sz(sumItems(waFiltered()))) +
      tile('shots', '📱', 'اسکرین شاٹس', 'Screenshots', sub.shots, sz(sumItems(S.x.shots))) +
      tile('blurry', '🌫', 'دھندلی تصاویر', 'Blurry photos', sub.blurry, sz(sumItems(S.x.blurry))) +
      tile('junk', '🧹', 'فالتو فائلیں', 'Junk files', sub.junk, sz(sumItems(S.x.junk))) +
      tile('old', '📥', 'پرانی ڈاؤن لوڈز', 'Old downloads', sub.old, sz(sumItems(S.x.old.filter(function (i) { return older(i, 30); })))) +
      tile('contacts', '👥', 'ڈپلیکیٹ کانٹیکٹس', 'Duplicate contacts', sub.contacts, '') +
      tile('monitor', '📈', 'فون مانیٹر', 'Phone monitor', ['بیٹری، RAM، استعمال', 'Battery, RAM, usage'], '') +
      tile('days', '🧭', 'سفر کا ریکارڈ', 'Travel log', ['روزانہ، نقشہ، قدم', 'Daily, map, steps'], '') +
      tile('trash', '♻', 'ٹریش', 'Trash', sub.trash, '') + '</div>' + footer();
    $('#scanbtn').onclick = chooseScan; wireBanner();
    [].forEach.call(document.querySelectorAll('[data-open]'), function (b) { b.onclick = function () { openTool(b.dataset.open); }; });
  }

  function vOverview() {
    setTop(T('نتیجہ', 'Results'));
    if (!S.scanned) return needScan();
    var rows = [['dups', '🖼', 'ڈپلیکیٹ فائلیں', 'Duplicates', dupBytes(), S.groups.length], ['large', '📦', 'بڑی فائلیں', 'Large files', sumItems(S.x.large), S.x.large.length], ['wa', '💬', 'واٹس ایپ', 'WhatsApp (3 months+)', sumItems(waFiltered()), waFiltered().length],
      ['shots', '📱', 'اسکرین شاٹس', 'Screenshots', sumItems(S.x.shots), S.x.shots.length], ['blurry', '🌫', 'دھندلی تصاویر', 'Blurry and dark', sumItems(S.x.blurry), S.x.blurry.length],
      ['junk', '🧹', 'فالتو فائلیں', 'Junk files', sumItems(S.x.junk), S.x.junk.length], ['old', '📥', 'پرانی ڈاؤن لوڈز', 'Old downloads', sumItems(S.x.old), S.x.old.length]];
    var h = '<div class="hero" style="display:block"><div class="k">' + T('آسانی سے بچ سکتا ہے', 'Easy wins') + '</div><div class="big">' + fmt(potential()) + '</div><div class="k" style="font-size:12.5px">' + nfiles(S.scanned) + ' ' + tt('دیکھی گئیں', 'checked') + '</div></div><div class="card">';
    rows.forEach(function (r) { h += '<button class="cat" data-open="' + r[0] + '"><span>' + r[1] + ' <b>' + (PREF.lang === 'en' ? r[3] : r[2]) + '</b>' + (PREF.lang === 'both' ? '<small class="e">' + r[3] + '</small>' : '') + '</span><span class="pill' + (r[5] ? ' a' : '') + '">' + r[5] + ' · ' + fmt(r[4]) + '</span></button>'; });
    $('#body').innerHTML = h + '</div>' + footer();
    [].forEach.call(document.querySelectorAll('[data-open]'), function (b) { b.onclick = function () { openTool(b.dataset.open); }; });
  }

  var PH = { walk: ['فائلیں گن رہا ہوں…', 'Counting files'], hash: ['ایک جیسی فائلیں ملا رہا ہوں…', 'Matching identical files'], similar: ['ملتی جلتی تصاویر دیکھ رہا ہوں…', 'Comparing similar photos'], quality: ['دھندلی تصاویر جانچ رہا ہوں…', 'Checking photo quality'], move: ['ٹریش میں بھیج رہا ہوں…', 'Moving to trash'] };
  function vScan() {
    setTop(T('اسکین ہو رہا ہے', 'Scanning')); setBottom(''); setNav(false);
    var p = S.prog || { phase: 'walk', done: 0, total: 0 }, ph = PH[p.phase] || PH.walk;
    $('#body').innerHTML = '<div class="card center"><div class="spin"></div><h2 style="font-size:20px">' + T(ph[0], ph[1]) + '</h2>' +
      '<div class="big" style="text-align:center;font-size:32px">' + p.done + (p.total ? ' / ' + p.total : '') + '</div><div class="bar"><i style="width:' + (p.total ? Math.round(p.done / p.total * 100) : 5) + '%"></i></div>' +
      '<p class="mut" style="margin-top:12px">' + tt('آپ پیچھے جا کر دوسرا کام کر سکتے ہیں، اسکین پس منظر میں چلتا رہے گا اور مکمل ہونے پر اطلاع آئے گی۔', 'You can go back and use the phone; the scan keeps running and you get a notification when it finishes.') + '</p>' +
      '<button class="btn o" id="scbg">' + T('پس منظر میں چلنے دیں', 'Run in background') + '</button><button class="btn o" id="sccx" style="color:var(--red)">' + T('اسکین روکیں', 'Cancel scan') + '</button></div>';
    $('#scbg').onclick = function () { goBack(); };
    $('#sccx').onclick = function () { try { P.scanCancel(); } catch (e) { /* ignore */ } };
  }
  function chooseScan() {
    var m = $('#modal'), last = store('scanmode') || 'fast'; m.hidden = false;
    $('#sheet').innerHTML = '<b style="font-size:18px">' + tt('کس طرح اسکین کریں؟', 'How should I scan?') + '</b>' +
      '<button class="card" id="sc1" style="width:100%;text-align:start;margin-top:12px;border:2px solid ' + (last === 'fast' ? 'var(--acc)' : 'var(--line)') + '"><b>⚡ ' + tt('فاسٹ کلین', 'Fast clean') + '</b><small class="e" style="display:block;font-size:12.5px;line-height:1.7;color:var(--mut)">' + tt('تقریباً 1-2 منٹ۔ کیمرہ، ڈاؤن لوڈ، واٹس ایپ، اسکرین شاٹ جیسی عام جگہیں؛ ہو بہو ایک جیسی فائلیں، کچرا اور بڑی فائلیں۔', 'About 1-2 min. Common places (camera, downloads, WhatsApp, screenshots): identical files, junk and big files.') + '</small></button>' +
      '<button class="card" id="sc2" style="width:100%;text-align:start;border:2px solid ' + (last === 'deep' ? 'var(--acc)' : 'var(--line)') + '"><b>🔬 ' + tt('تفصیلی کلین', 'Detailed clean') + '</b><small class="e" style="display:block;font-size:12.5px;line-height:1.7;color:var(--mut)">' + tt('زیادہ وقت (10 منٹ یا زیادہ)۔ پورا فون، ملتی جلتی اور دھندلی تصاویر، خالی فولڈر۔', 'Takes longer (10+ min). Whole phone, similar and blurry photos, empty folders.') + '</small></button>' +
      '<button class="btn o" id="scx">' + tt('منسوخ', 'Cancel') + '</button>';
    $('#sc1').onclick = function () { m.hidden = true; store('scanmode', 'fast'); startScan('fast'); };
    $('#sc2').onclick = function () { m.hidden = true; store('scanmode', 'deep'); startScan('deep'); };
    $('#scx').onclick = function () { m.hidden = true; };
  }
  function applyScan(r) { prepare(r.groups || [], r.extras); S.scanned = r.files || 1; savePotential(); }
  function scanBanner() {
    if (S.scanRun) { var p = S.prog || {}; return '<button class="card" id="scrun" style="width:100%;text-align:start;margin-top:12px;border-color:var(--acc)"><b>🔄 ' + tt('اسکین چل رہا ہے', 'Scan is running') + '</b><small class="e" style="display:block;color:var(--mut)">' + (p.total ? p.done + ' / ' + p.total : (p.done || '')) + ' · ' + tt('دیکھنے کے لیے ٹیپ کریں', 'tap to watch') + '</small></button>'; }
    if (S.bgDone) return '<button class="card" id="scdn" style="width:100%;text-align:start;margin-top:12px;border-color:var(--acc)"><b>✅ ' + tt('اسکین مکمل', 'Scan finished') + '</b><small class="e" style="display:block;color:var(--mut)">' + tt('نتیجہ دیکھنے کے لیے ٹیپ کریں', 'tap to see the results') + '</small></button>';
    return '';
  }
  function wireBanner() {
    var a = $('#scrun'), b = $('#scdn');
    if (a) a.onclick = function () { S.view = 'scanning'; S.back = []; render(); };
    if (b) b.onclick = function () { S.bgDone = false; S.view = 'overview'; S.back = []; render(); };
  }
  var scanTick = 0;
  function startScan(mode) {
    mode = mode === 'deep' ? 'deep' : 'fast';
    S.view = 'scanning'; S.back = []; S.scanRun = true; S.bgDone = false; S.prog = { phase: 'walk', done: 0, total: 0 }; render();
    var h;
    try {
      var lr = P.addListener('progress', function (e) {
        S.prog = e; var now = Date.now();
        if (S.view === 'scanning' && now - scanTick > 250) { scanTick = now; vScan(); }
      });
      if (lr && lr.then) lr.then(function (x) { h = x; }); else h = lr;
    } catch (e) { /* progress is optional */ }
    P.scan({ mode: mode, similar: PREF.similar, quality: PREF.quality, skip: PREF.protect }).then(function (r) {
      try { if (h && h.remove) h.remove(); } catch (e) { /* ignore */ }
      S.scanRun = false; applyScan(r);
      if (S.view === 'scanning') { S.view = 'overview'; S.back = []; render(); }
      else { S.bgDone = true; if (S.view === 'home') render(); toast('اسکین مکمل، نتیجہ ٹولز میں دیکھیں', 'Scan finished, see the results in Tools'); }
    }).catch(function (e) {
      try { if (h && h.remove) h.remove(); } catch (e2) { /* ignore */ }
      S.scanRun = false; if (S.view === 'scanning') S.view = 'home'; render();
      if (e && /cancel/i.test(e.message || '')) toast('اسکین روک دیا', 'Scan cancelled'); else toast('اسکین نہیں ہو سکا', 'Scan failed: ' + (e && e.message || e));
    });
  }
  /* the app was closed while a scan ran: pick the scan up again */
  function resumeScan() {
    try {
      P.scanStatus().then(function (st) {
        if (!st) return;
        var take = function () { P.scanTake().then(function (r) { if (r && r.groups) { applyScan(r); S.bgDone = true; S.scanRun = false; if (S.view === 'home') render(); } }).catch(function () { /* ignore */ }); };
        if (st.running && !S.scanRun) {
          S.scanRun = true; S.prog = { phase: st.phase, done: st.done, total: st.total };
          var iv = setInterval(function () { P.scanStatus().then(function (x) { S.prog = { phase: x.phase, done: x.done, total: x.total }; if (S.view === 'scanning') vScan(); if (!x.running) { clearInterval(iv); S.scanRun = false; take(); } }).catch(function () { clearInterval(iv); }); }, 1000);
        } else if (st.hasResult && !S.scanRun) take();
      }).catch(function () { /* old plugin */ });
    } catch (e) { /* ignore */ }
  }

  /* duplicates overview (categories) */
  function vDups() {
    setTop(T('ڈپلیکیٹ فائلیں', 'Duplicates'));
    if (!S.scanned) return needScan();
    var any = S.groups.length > 0, possible = dupBytes();
    if (!any) { $('#body').innerHTML = '<div class="card center"><div style="font-size:54px">✨</div><h2 style="font-size:22px">' + T('کوئی ڈپلیکیٹ نہیں ملا', 'No duplicates found') + '</h2></div>' + footer(); return; }
    var h = '<div class="hero" style="display:block"><div class="k">' + T('آپ بچا سکتے ہیں', 'You can save up to') + '</div><div class="big">' + fmt(possible) + '</div><div class="k">' + S.groups.length + ' ' + tt('گروپ', 'groups') + '</div></div><div class="card">';
    CATS.forEach(function (c) {
      var s = catStats(c.id); if (!s.groups) return;
      h += '<button class="cat" data-cat="' + c.id + '"><span>' + c.ic + ' <b>' + (PREF.lang === 'en' ? c.en : c.ur) + '</b>' + (PREF.lang === 'both' ? '<small class="e">' + c.en + '</small>' : '') + '</span><span class="pill a">' + s.groups + ' · ' + fmt(s.bytes) + (s.sel ? ' · ✓' + s.sel : '') + '</span></button>';
    });
    h += '</div><p class="mut" style="margin-top:12px">' + tt('ہو بہو ایک جیسی فائلیں پہلے سے چنی ہوئی ہیں اور ہر گروپ میں ایک اصل فائل رہے گی۔ ملتی جلتی تصاویر آپ خود دیکھ کر چنیں۔', 'Exact copies are pre-selected and one original always stays in each group. Choose similar photos yourself.') + '</p>';
    $('#body').innerHTML = h + footer();
    [].forEach.call(document.querySelectorAll('[data-cat]'), function (b) { b.onclick = function () { go('review', b.dataset.cat); }; });
    moveBar();
  }

  function vReview() {
    var cat = CATS.filter(function (c) { return c.id === S.review; })[0];
    setTop(catLabel(cat));
    var gs = S.groups.filter(function (g) { return g.cat === cat.id; });
    var isSim = cat.id === 'simg';
    var h = '<div class="tabs"><button id="selall">' + T(isSim ? 'تجویز کردہ چنیں' : 'سب تجویز کردہ چنیں', 'Select suggested') + '</button><button id="selnone">' + T('کچھ نہ چنیں', 'Select none') + '</button></div>' +
      '<p class="mut" style="margin-top:8px">' + tt('تصویر پر ٹچ کر کے رکھیں/ہٹائیں بدلیں۔ سبز = رکھیں، سرخ = ٹریش میں جائے گی۔', 'Tap a photo to switch keep/remove. Green = keep, red = goes to trash.') + '</p>';
    gs.forEach(function (g) {
      var sv = 0; g.items.forEach(function (it) { if (S.sel[it.path]) sv += it.size; });
      h += '<div class="grp" data-g="' + g.id + '"><div class="hd"><span>' + nfiles(g.items.length) + ' · ' + (g.type === 'similar' ? tt('ملتی جلتی', 'similar') : tt('ایک جیسی', 'identical')) + '</span><span class="pill">' + (sv ? '−' + fmt(sv) : fmt(g.size)) + '</span></div><div class="thumbs">';
      g.items.forEach(function (it) {
        var del = !!S.sel[it.path], k = kind(it.path);
        h += '<button class="th ' + (del ? 'del' : 'keep') + '" data-p="' + esc(it.path) + '"><div class="im" ' + (k === 'img' || k === 'vid' ? 'data-p="' + esc(it.path) + '"' : '') + '>' + (k === 'img' || k === 'vid' ? '' : esc(ext(it.path) || 'file')) + '</div><div class="nm">' + esc(base(it.path)) + '</div><div class="nm">' + esc(folder(it.path)) + ' · ' + fmt(it.size) + '</div><div class="st">' + (del ? tt('ہٹائیں', 'Remove') : (it.path === g.keeper ? tt('رکھیں ★', 'Keep ★') : tt('رکھیں', 'Keep'))) + '</div></button>';
      });
      h += '</div></div>';
    });
    $('#body').innerHTML = h;
    watchThumbs($('#body'));
    $('#selall').onclick = function () { gs.forEach(function (g) { g.items.forEach(function (it) { if (it.path !== g.keeper) S.sel[it.path] = it.size; else delete S.sel[it.path]; }); }); vReview(); };
    $('#selnone').onclick = function () { gs.forEach(function (g) { g.items.forEach(function (it) { delete S.sel[it.path]; }); }); vReview(); };
    $('#body').onclick = function (e) {
      var th = e.target.closest('.th'); if (!th) return;
      var gel = th.closest('[data-g]'), g = S.groups[+gel.dataset.g], p = th.dataset.p, it = g.items.filter(function (x) { return x.path === p; })[0];
      if (S.sel[p]) delete S.sel[p];
      else {
        var left = g.items.filter(function (x) { return x.path !== p && !S.sel[x.path]; }).length;
        if (!left) return toast('ہر گروپ میں ایک کاپی رکھنا ضروری ہے', 'At least one copy must stay');
        S.sel[p] = it.size;
      }
      var y = $('#body').scrollTop; vReview(); $('#body').scrollTop = y;
    };
    moveBar();
  }

  /* generic list: large files, screenshots, blurry, junk, old downloads, WhatsApp types */
  function chipsHtml(def) {
    var h = '';
    def.chips.forEach(function (c) {
      h += '<div class="chips">';
      c.opts.forEach(function (o) { h += '<button class="chip' + (S.f[c.key] === o[0] ? ' on' : '') + '" data-f="' + c.key + '" data-v="' + o[0] + '">' + (PREF.lang === 'en' ? o[2] : o[1]) + '</button>'; });
      h += '</div>';
    });
    return h;
  }
  function vList() {
    var def = listDef(S.list);
    setTop(T(def.ur, def.en));
    if (!S.scanned) return needScan();
    var items = def.items, total = sumItems(items), shown = items.slice(0, S.limit);
    var h = '<p class="mut" style="margin-top:6px">' + tt(def.hint[0], def.hint[1]) + '</p>' + chipsHtml(def) +
      '<div class="card" style="margin-top:12px;padding:10px 14px"><span class="mut">' + nfiles(items.length) + ' · </span><b style="font-family:system-ui;color:var(--acc)">' + fmt(total) + '</b></div>';
    if (!items.length) h += '<div class="card center"><div style="font-size:46px">✨</div><h2 style="font-size:19px">' + T('کچھ نہیں ملا', 'Nothing found') + '</h2></div>';
    else {
      h += '<div class="tabs"><button id="selall">' + T('سب چنیں', 'Select all') + '</button><button id="selnone">' + T('کچھ نہ چنیں', 'Select none') + '</button></div><div class="lg">';
      shown.forEach(function (it) {
        var on = !!S.sel[it.path], k = it.dir ? 'dir' : kind(it.path), media = k === 'img' || k === 'vid';
        h += '<button class="th' + (on ? ' del' : '') + '" data-p="' + esc(it.path) + '"><div class="im" ' + (media ? 'data-p="' + esc(it.path) + '"' : '') + '>' + (media ? '' : (it.dir ? '📁' : esc(ext(it.path) || 'file'))) + '</div>' +
          (it.reason ? '<span class="tag">' + (it.reason === 'dark' ? tt('تاریک', 'dark') : tt('دھندلی', 'blur')) + '</span>' : '') +
          '<div class="nm">' + esc(base(it.path)) + '</div><div class="nm">' + esc(it.dir ? folder(it.path) : fmt(it.size) + ' · ' + new Date(it.mtime).toISOString().slice(0, 10)) + '</div><div class="st">' + (on ? tt('ہٹائیں', 'Remove') : '&nbsp;') + '</div></button>';
      });
      h += '</div>';
      if (items.length > shown.length) h += '<button class="btn o" id="more">' + T('مزید دکھائیں', 'Show more') + '</button>';
    }
    $('#body').innerHTML = h;
    watchThumbs($('#body'));
    [].forEach.call(document.querySelectorAll('[data-f]'), function (b) {
      b.onclick = function () { var v = b.dataset.v; S.f[b.dataset.f] = isNaN(+v) || v === '' ? v : +v; S.limit = 150; vList(); };
    });
    if (items.length) {
      $('#selall').onclick = function () { items.forEach(function (it) { S.sel[it.path] = it.size; }); var y = $('#body').scrollTop; vList(); $('#body').scrollTop = y; };
      $('#selnone').onclick = function () { items.forEach(function (it) { delete S.sel[it.path]; }); var y = $('#body').scrollTop; vList(); $('#body').scrollTop = y; };
      $('#body').onclick = function (e) {
        var th = e.target.closest('.th'); if (!th) return;
        var p = th.dataset.p, it = items.filter(function (x) { return x.path === p; })[0];
        if (S.sel[p] !== undefined) delete S.sel[p]; else S.sel[p] = it.size;
        var y = $('#body').scrollTop; vList(); $('#body').scrollTop = y;
      };
    }
    if ($('#more')) $('#more').onclick = function () { S.limit += 150; var y = $('#body').scrollTop; vList(); $('#body').scrollTop = y; };
    moveBar();
  }

  function vWa() {
    setTop(T('واٹس ایپ صفائی', 'WhatsApp cleaner'));
    if (!S.scanned) return needScan();
    var f = waFiltered();
    var h = '<p class="mut" style="margin-top:6px">' + tt('واٹس ایپ کا پرانا میڈیا۔ چیٹ کا متن نہیں چھیڑا جاتا۔', 'Old WhatsApp media. Your chat text is not touched.') + '</p>' + chipsHtml({ chips: [AGE_OPTS('waAge'), { key: 'waDir', opts: [['all', 'سب', 'All'], ['recv', 'موصول شدہ', 'Received'], ['sent', 'بھیجی ہوئی', 'Sent']] }] }) + '<div class="card">';
    WA_TYPES.forEach(function (t) {
      var l = f.filter(function (i) { return waType(i) === t.id; });
      h += '<button class="cat" data-wt="' + t.id + '"><span>' + t.ic + ' <b>' + (PREF.lang === 'en' ? t.en : t.ur) + '</b>' + (PREF.lang === 'both' ? '<small class="e">' + t.en + '</small>' : '') + '<small class="e" style="display:block">' + nfiles(l.length) + '</small></span><span class="pill a">' + fmt(sumItems(l)) + '</span></button>';
    });
    $('#body').innerHTML = h + '</div>' + footer();
    [].forEach.call(document.querySelectorAll('[data-f]'), function (b) { b.onclick = function () { var v = b.dataset.v; S.f[b.dataset.f] = isNaN(+v) ? v : +v; vWa(); }; });
    [].forEach.call(document.querySelectorAll('[data-wt]'), function (b) { b.onclick = function () { go('list', 'wa:' + b.dataset.wt); }; });
    moveBar();
  }

  /* ---------- move to trash ---------- */
  function confirmMove() {
    var t = selTotals(); if (!t.n) return;
    var m = $('#modal'); m.hidden = false;
    $('#sheet').innerHTML = '<h2 style="font-size:22px">' + T('تصدیق', 'Confirm') + '</h2><p style="margin-top:6px">' + tt(t.n + ' آئٹم ٹریش میں جائیں گے۔', t.n + ' items will go to trash.') + '</p><div class="big" style="font-size:32px">' + fmt(t.b) + '</div>' +
      '<p class="mut">' + tt('فائلیں فوراً ختم نہیں ہوتیں۔ ' + PREF.trashDays + ' دن تک ٹریش میں رہتی ہیں اور آپ واپس لا سکتے ہیں۔ ڈپلیکیٹ گروپ میں ایک اصل فائل رہے گی۔', 'Nothing is deleted right away. Files stay in the trash for ' + PREF.trashDays + ' days and you can restore them. One original always stays in each duplicate group.') + '</p>' +
      '<button class="btn" id="okmove">' + T('ٹریش میں بھیجیں', 'Move to trash') + '</button><button class="btn o" id="nomove">' + T('واپس جائیں', 'Cancel') + '</button>';
    $('#nomove').onclick = function () { m.hidden = true; };
    $('#okmove').onclick = function () { m.hidden = true; doMove(); };
  }
  function doMove() {
    var all = Object.keys(S.sel), dirs = all.filter(function (p) { return S.dirSet[p]; }), paths = all.filter(function (p) { return !S.dirSet[p]; }), done = 0, bytes = 0, i = 0, total = all.length;
    S.view = 'scanning'; S.prog = { phase: 'move', done: 0, total: total }; render();
    (function next() {
      if (i >= paths.length) {
        if (!dirs.length) return finishMove(done, bytes);
        return P.deleteEmptyDirs({ paths: dirs }).then(function (r) { done += (r && r.deleted) || 0; finishMove(done, bytes); }).catch(function () { finishMove(done, bytes); });
      }
      var chunk = paths.slice(i, i + 40); i += 40;
      P.trashMove({ paths: chunk }).then(function (r) { done += r.moved || 0; bytes += r.bytes || 0; S.prog = { phase: 'move', done: Math.min(i, total), total: total }; vScan(); next(); })
        .catch(function () { next(); });
    })();
  }
  function finishMove(done, bytes) {
    var gone = {}; Object.keys(S.sel).forEach(function (p) { gone[p] = 1; });
    function keep(it) { return !gone[it.path]; }
    S.groups.forEach(function (g) { g.items = g.items.filter(keep); });
    S.groups = S.groups.filter(function (g) { return g.items.length > 1; });
    S.groups.forEach(function (g) { if (!g.items.some(function (it) { return it.path === g.keeper; })) g.keeper = best(g.items, true).path; });
    ['large', 'wa', 'shots', 'junk', 'old', 'blurry'].forEach(function (k) { S.x[k] = S.x[k].filter(keep); });
    S.sel = {}; S.lastMoved = { n: done, b: bytes }; S.back = [];
    store('freed', (store('freed') || 0) + bytes);
    savePotential(); S.view = 'done'; render(); refreshStatus(true);
  }
  function vDone() {
    setTop(T('مکمل', 'Done')); setBottom('');
    var m = S.lastMoved || { n: 0, b: 0 };
    $('#body').innerHTML = '<div class="card center"><div style="font-size:54px">✅</div><h2 style="font-size:21px">' + T(m.n + ' آئٹم ٹریش میں بھیج دیے گئے', m.n + ' items moved to trash') + '</h2><div class="big" style="text-align:center">' + fmt(m.b) + '</div>' +
      '<p class="mut" style="margin-top:8px">' + tt('جگہ تب خالی ہو گی جب آپ ٹریش خالی کریں گے۔ ' + PREF.trashDays + ' دن بعد ٹریش خود خالی ہو جاتا ہے۔', 'Space is freed when the trash is emptied. It also empties itself after ' + PREF.trashDays + ' days.') + '</p>' +
      '<div class="row" style="margin-top:8px"><div class="t"><span class="mut">' + tt('اب تک کل صفائی', 'Total cleaned so far') + '</span></div><b style="font-family:system-ui;color:var(--acc)">' + fmt(store('freed') || 0) + '</b></div>' +
      '<button class="btn" id="emptynow">' + T('ٹریش ابھی خالی کریں', 'Empty trash now') + '</button><button class="btn o" id="later">' + T('بعد میں', 'Later') + '</button></div>' + footer();
    $('#emptynow').onclick = function () { P.trashEmpty({}).then(function (r) { toast('جگہ خالی ہو گئی: ' + fmt(r.freed || 0), 'Freed ' + fmt(r.freed || 0)); S.view = 'home'; refreshStatus(); }).catch(function () { toast('خالی نہیں ہو سکا', 'Could not empty'); }); };
    $('#later').onclick = function () { S.view = 'overview'; S.back = []; refreshStatus(); };
  }

  /* ---------- trash ---------- */
  function loadTrash() {
    return P.trashList().then(function (r) { S.trash = { items: r.items || [], bytes: r.bytes || 0 }; S.trashSel = {}; }).catch(function () { S.trash = { items: [], bytes: 0 }; });
  }
  function vTrash() {
    setTop(T('ٹریش', 'Trash'));
    var tr = S.trash, now = Date.now();
    if (!tr.items.length) { $('#body').innerHTML = '<div class="card center"><div style="font-size:54px">🗑</div><h2 style="font-size:20px">' + T('ٹریش خالی ہے', 'Trash is empty') + '</h2></div>' + footer(); return; }
    var h = '<div class="hero" style="display:block"><div class="k">' + T('ٹریش میں', 'In trash') + '</div><div class="big">' + fmt(tr.bytes) + '</div><div class="k">' + nfiles(tr.items.length) + '</div></div>' +
      '<div class="tabs"><button id="tall">' + T('سب چنیں', 'Select all') + '</button><button id="tnone">' + T('کچھ نہ چنیں', 'None') + '</button></div><div class="card" id="tlist">';
    tr.items.forEach(function (it) {
      var left = Math.max(0, PREF.trashDays - Math.floor((now - it.ts) / 86400000));
      h += '<button class="cat" data-t="' + esc(it.id) + '"><span class="sw" aria-pressed="' + !!S.trashSel[it.id] + '"></span><span class="t" style="flex:1;min-width:0;text-align:start"><b style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;font-family:system-ui;font-size:14px;text-align:start">' + esc(base(it.original)) + '</b><small class="e" style="display:block">' + esc(folder(it.original)) + ' · ' + left + ' ' + tt('دن باقی', 'days left') + '</small></span><span class="pill">' + fmt(it.size) + '</span></button>';
    });
    h += '</div>';
    $('#body').innerHTML = h;
    var n = Object.keys(S.trashSel).length;
    setBottom('<div style="display:flex;gap:10px"><button class="btn" id="restore" style="flex:1"' + (n ? '' : ' disabled') + '>' + T('واپس لائیں', 'Restore') + '</button><button class="btn red" id="purge" style="flex:1"' + (n ? '' : ' disabled') + '>' + T('ہمیشہ کے لیے ہٹائیں', 'Delete forever') + '</button></div><button class="btn o" id="purgeall" style="margin-top:8px;min-height:44px">' + T('پوری ٹریش خالی کریں', 'Empty all trash') + '</button>');
    $('#tall').onclick = function () { tr.items.forEach(function (it) { S.trashSel[it.id] = 1; }); vTrash(); };
    $('#tnone').onclick = function () { S.trashSel = {}; vTrash(); };
    $('#tlist').onclick = function (e) { var b = e.target.closest('[data-t]'); if (!b) return; var id = b.dataset.t; if (S.trashSel[id]) delete S.trashSel[id]; else S.trashSel[id] = 1; var y = $('#body').scrollTop; vTrash(); $('#body').scrollTop = y; };
    $('#restore').onclick = function () {
      var ids = Object.keys(S.trashSel), back = 0; tr.items.forEach(function (it) { if (S.trashSel[it.id]) back += it.size; });
      P.trashRestore({ ids: ids }).then(function (r) { store('freed', Math.max(0, (store('freed') || 0) - back)); toast('واپس آ گئیں: ' + (r.restored || 0), 'Restored ' + (r.restored || 0)); loadTrash().then(vTrash); });
    };
    $('#purge').onclick = function () { askForever(Object.keys(S.trashSel)); };
    $('#purgeall').onclick = function () { askForever(null); };
  }
  function askForever(ids) {
    var m = $('#modal'); m.hidden = false;
    $('#sheet').innerHTML = '<h2 style="font-size:22px">' + T('کیا ہمیشہ کے لیے ہٹائیں؟', 'Delete forever?') + '</h2><p class="mut" style="margin-top:6px">' + tt('یہ فائلیں دوبارہ واپس نہیں آئیں گی۔', 'These files cannot be brought back.') + '</p><button class="btn red" id="yesforever">' + T('ہاں، ہٹا دیں', 'Yes, delete') + '</button><button class="btn o" id="noforever">' + T('منسوخ', 'Cancel') + '</button>';
    $('#noforever').onclick = function () { m.hidden = true; };
    $('#yesforever').onclick = function () { m.hidden = true; P.trashEmpty(ids ? { ids: ids } : {}).then(function (r) { toast('جگہ خالی ہو گئی: ' + fmt(r.freed || 0), 'Freed ' + fmt(r.freed || 0)); loadTrash().then(vTrash); refreshStatus(true); }); };
  }

  /* ---------- settings ---------- */
  function chipRow(key, opts) {
    return '<div class="chips">' + opts.map(function (o) { return '<button class="chip' + (PREF[key] === o[0] ? ' on' : '') + '" data-pref="' + key + '" data-v="' + o[0] + '">' + (PREF.lang === 'en' ? o[2] : o[1]) + '</button>'; }).join('') + '</div>';
  }
  function swRow(key, ur, en, sub) {
    return '<div class="row"><div class="t"><b>' + (PREF.lang === 'en' ? en : ur) + '</b><small class="e" style="display:block">' + (PREF.lang === 'en' ? sub[1] : sub[0]) + '</small></div><button class="sw" data-sw="' + key + '" aria-pressed="' + !!PREF[key] + '" aria-label="' + en + '"></button></div>';
  }
  function vSettings() {
    setTop(T('ترتیبات', 'Settings'));
    var h = '<div class="card"><div class="row"><div class="t"><b>' + tt('زبان', 'Language') + '</b></div></div>' + chipRow('lang', [['en', 'English', 'English'], ['ur', 'اردو', 'اردو'], ['both', 'اردو + English', 'اردو + English']]) +
      '<div class="row" style="margin-top:6px"><div class="t"><b>' + tt('تھیم', 'Theme') + '</b></div></div>' + chipRow('theme', [['dark', 'ڈارک', 'Dark'], ['light', 'لائٹ', 'Light'], ['auto', 'خودکار', 'Auto']]) +
      '<div class="row" style="margin-top:6px"><div class="t"><b>' + tt('رنگ', 'Accent colour') + '</b></div></div>' + chipRow('accent', [['teal', 'فیروزی', 'Teal'], ['blue', 'نیلا', 'Blue'], ['violet', 'جامنی', 'Violet'], ['rose', 'گلابی', 'Rose'], ['amber', 'نارنجی', 'Amber'], ['green', 'سبز', 'Green']]) + '</div>' +
      '<div class="card">' + swRow('similar', 'ملتی جلتی تصاویر', 'Find similar photos', ['اسکین سست مگر زیادہ نتائج', 'Slower scan, more results']) + swRow('quality', 'دھندلی تصاویر جانچیں', 'Check blurry photos', ['اسکین میں کچھ زیادہ وقت لگے گا', 'Adds some time to the scan']) + '</div>' +
      '<div class="card"><div class="row"><div class="t"><b>' + tt('ڈپلیکیٹ میں کون سی کاپی رکھیں', 'Which copy to keep') + '</b></div></div>' + chipRow('keep', [['camera', 'کیمرہ اصل', 'Camera original'], ['oldest', 'سب سے پرانی', 'Oldest'], ['newest', 'سب سے نئی', 'Newest'], ['largest', 'سب سے بڑی', 'Largest']]) + '</div>' +
      '<div class="card"><button class="cat" id="protbtn" style="padding:6px 0"><span class="t"><b>' + tt('محفوظ فولڈرز', 'Protected folders') + '</b><small class="e" style="display:block">' + tt('کبھی اسکین نہیں ہوں گے · ' + PREF.protect.length, 'Never scanned · ' + PREF.protect.length) + '</small></span><span class="pill a">' + tt('بدلیں', 'Edit') + '</span></button></div>' +
      '<div class="card">' + swRow('remind', 'ماہانہ یاد دہانی', 'Monthly reminder', ['ہر مہینے صفائی کی یاد دہانی', 'A nudge to clean once a month']) + '<div class="row"><div class="t"><b>' + tt('ٹریش خود خالی ہو', 'Trash auto-empty') + '</b></div></div>' + chipRow('trashDays', [[7, '7 دن', '7 days'], [30, '30 دن', '30 days'], [60, '60 دن', '60 days'], [90, '90 دن', '90 days']]) + '</div>' +
      '<div class="card center"><div class="logo" style="margin:0 auto 8px;width:56px;height:56px;border-radius:17px;font-size:26px">✦</div><b style="font-size:19px;font-family:system-ui">Cleanova Life</b><div class="mut" style="font-family:system-ui;font-size:12.5px;line-height:1.8;margin-top:4px">Version 2.0 · ' + tt('مفت · اشتہارات نہیں', 'Free · No ads') + '<br>' + tt('سارا اسکین آپ کے فون میں ہی ہوتا ہے', 'All scanning stays on your phone') + '<br><span style="color:var(--acc);font-weight:700">Developed by SMAA</span></div></div>' +
      '<div class="card"><button class="cat" id="prbtn" style="padding:6px 0"><span class="t"><b>' + tt('پرائیویسی، لاک اور ڈسپلے', 'Privacy, lock and display') + '</b><small class="e" style="display:block">' + tt('پن، فنگر پرنٹ، بڑے حروف', 'PIN, fingerprint, large text') + '</small></span><span>›</span></button></div>' +
      '<div class="card"><button class="cat" id="bkbtn" style="padding:6px 0"><span class="t"><b>' + tt('بیک اپ اور بحالی', 'Backup and restore') + '</b><small class="e" style="display:block">' + tt('صحت، خرچ، یاد دہانیاں محفوظ کریں', 'Save health, expenses, reminders') + '</small></span><span>›</span></button></div>' +
      '<div class="card"><div class="mut">' + tt('اب تک کل صفائی', 'Total cleaned so far') + '</div><div class="big">' + fmt(store('freed') || 0) + '</div></div>' +
      (window.LifeStats ? '<div class="card">' + '<div class="row"><div class="t"><b>' + tt('گمنام استعمال کی گنتی', 'Anonymous usage counts') + '</b><small class="e" style="display:block">' + tt('صرف کھولنے کی تعداد اور ورژن۔ نام، نمبر، پیغام، تصاویر یا لوکیشن کبھی نہیں جاتے۔', 'Only open counts and version. Never your name, number, messages, photos or location.') + '</small></div><button class="sw" id="stsw" aria-pressed="' + window.LifeStats.on() + '" aria-label="usage counts"></button></div></div>' : '') +
      '<div class="card"><button class="cat" id="dgbtn" style="padding:6px 0"><span class="t"><b>🩺 ' + tt('سیٹ اپ اور ہیلتھ چیک', 'Setup and health check') + '</b><small class="e" style="display:block">' + tt('نوٹیفکیشن، بیٹری، کنکشن اور ورژن چیک کریں', 'Check notifications, battery, connection and version') + '</small></span></button></div>';
    $('#body').innerHTML = h;
    $('#dgbtn').onclick = function () { go('diag'); };
    if ($('#stsw')) $('#stsw').onclick = function () { window.LifeStats.set(!window.LifeStats.on()); vSettings(); };
    [].forEach.call(document.querySelectorAll('[data-pref]'), function (b) {
      b.onclick = function () {
        var k = b.dataset.pref, v = b.dataset.v; v = isNaN(+v) ? v : +v;
        setPref(k, v); if (k === 'lang' || k === 'theme' || k === 'accent') applyLook(); if (k === 'trashDays') P.trashPurge({ days: v }).catch(function () { /* ignore */ });
        var y = $('#body').scrollTop; render(); $('#body').scrollTop = y;
      };
    });
    [].forEach.call(document.querySelectorAll('[data-sw]'), function (b) {
      b.onclick = function () {
        var k = b.dataset.sw, v = !PREF[k];
        if (k === 'remind') return setReminder(v).then(function () { vSettings(); });
        setPref(k, v); vSettings();
      };
    });
    $('#protbtn').onclick = protectSheet;
    $('#bkbtn').onclick = function () { go('backup'); };
    $('#prbtn').onclick = function () { go('prefs'); };
  }
  function protectSheet() {
    P.dirs().then(function (r) {
      var m = $('#modal'); m.hidden = false;
      var h = '<h2 style="font-size:21px">' + T('محفوظ فولڈرز', 'Protected folders') + '</h2><p class="mut">' + tt('چنے ہوئے فولڈرز کبھی اسکین یا صاف نہیں ہوں گے۔', 'Selected folders are never scanned or cleaned.') + '</p><div class="card" id="plist">';
      (r.dirs || []).forEach(function (d) { h += '<button class="cat" data-d="' + esc(d.path) + '"><span class="sw" aria-pressed="' + (PREF.protect.indexOf(d.path) >= 0) + '"></span><span class="t" style="flex:1;font-family:system-ui;text-align:start">' + esc(d.name) + '</span></button>'; });
      $('#sheet').innerHTML = h + '</div><button class="btn" id="pdone">' + T('ٹھیک ہے', 'Done') + '</button>';
      $('#plist').onclick = function (e) {
        var b = e.target.closest('[data-d]'); if (!b) return; var p = b.dataset.d, i = PREF.protect.indexOf(p);
        if (i >= 0) PREF.protect.splice(i, 1); else PREF.protect.push(p);
        store('protect', PREF.protect); b.querySelector('.sw').setAttribute('aria-pressed', String(PREF.protect.indexOf(p) >= 0));
      };
      $('#pdone').onclick = function () { m.hidden = true; vSettings(); };
    }).catch(function () { toast('فولڈر نہیں مل سکے', 'Could not list folders'); });
  }
  function setReminder(on) {
    if (!LN) { setPref('remind', on); toast(on ? 'یاد دہانی آن (صرف ایپ میں)' : 'یاد دہانی بند', on ? 'Reminder on (app only)' : 'Reminder off'); return Promise.resolve(); }
    if (!on) { setPref('remind', false); return LN.cancel({ notifications: [{ id: 7001 }] }).catch(function () { /* ignore */ }); }
    return LN.requestPermissions().then(function (r) {
      if (!r || r.display !== 'granted') { toast('نوٹیفکیشن کی اجازت نہیں ملی', 'Notification permission denied'); return; }
      return LN.schedule({ notifications: [{ id: 7001, title: 'Cleanova', body: 'مہینے کی صفائی کا وقت ہے · Time for a monthly clean-up', schedule: { on: { day: 1, hour: 10, minute: 0 }, allowWhileIdle: true } }] }).then(function () { setPref('remind', true); toast('ہر مہینے کی 1 تاریخ کو یاد دلاؤں گا', 'I will remind you on the 1st of each month'); });
    }).catch(function () { toast('چالو نہیں ہو سکا', 'Could not turn on'); });
  }

  /* ---------- duplicate contacts (merge by default, always backed up first) ---------- */
  /* ---------- daily movement log with map ---------- */
  var dayTimer = 0, pnQ = [], pnBusy = false, PN = {};
  function clearDays() { if (dayTimer) { clearInterval(dayTimer); dayTimer = 0; } }
  var WD_UR = ['اتوار', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ'], WD_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  function keyDate(k) { return new Date(+k.slice(0, 4), +k.slice(4, 6) - 1, +k.slice(6, 8)); }
  function dayLabel(k) { var d = keyDate(k), t = new Date(), y = new Date(Date.now() - 86400000), same = function (a, b) { return a.toDateString() === b.toDateString(); }; if (same(d, t)) return tt('آج', 'Today'); if (same(d, y)) return tt('کل', 'Yesterday'); return (PREF.lang === 'en' ? WD_EN : WD_UR)[d.getDay()] + ' · ' + d.getDate() + '/' + (d.getMonth() + 1); }
  function pkey(lat, lon) { return lat.toFixed(3) + ',' + lon.toFixed(3); }
  function pname(lat, lon, again) {
    var k = pkey(lat, lon); if (PN[k] !== undefined) return PN[k];
    PN[k] = ''; pnQ.push([lat, lon, k, again]); pnRun(); return '';
  }
  function pnRun() {
    if (pnBusy || !pnQ.length) return; pnBusy = true;
    var j = pnQ.shift();
    TP.placeName({ lat: j[0], lon: j[1] }).then(function (r) { PN[j[2]] = (r && r.name) || ''; }).catch(function () { /* offline */ }).then(function () { pnBusy = false; if (S.view === 'day' && PN[j[2]]) { S.dayRedraw && S.dayRedraw(); } pnRun(); });
  }
  function nm(lat, lon) { var sv = CL.savedName && CL.savedName(lat, lon); if (sv) return esc(sv); var n = pname(lat, lon); return n || ('\u2066' + lat.toFixed(4) + ', ' + lon.toFixed(4) + '\u2069'); }
  function gmaps(o) {
    var u = o.to ? 'https://www.google.com/maps/dir/?api=1&origin=' + o.from[0] + ',' + o.from[1] + '&destination=' + o.to[0] + ',' + o.to[1] : 'https://www.google.com/maps/search/?api=1&query=' + o.at[0] + ',' + o.at[1];
    TP.openUrl({ url: u }).catch(function () { window.open(u, '_blank'); });
  }
  function vDays(soft) {
    setTop(T('روزانہ سفر', 'Daily movement'));
    var Dd = S.dl = S.dl || {};
    if (!soft) {
      clearDays();
      var load = function () {
        TP.autoStatus().then(function (r) { Dd.auto = r; if (r.on && r.loc && !CL.svcKick) { CL.svcKick = 1; TP.autoSet({ on: true }).catch(function () { /* ignore */ }); } if (S.view === 'days') vDays(true); }).catch(function () { Dd.auto = { on: false, loc: false }; });
        TP.dayList({ days: 60 }).then(function (r) { Dd.days = (r && r.days) || []; if (S.view === 'days') vDays(true); }).catch(function () { Dd.days = []; });
      };
      load(); dayTimer = setInterval(function () { if (S.view !== 'days') return clearDays(); load(); }, 15000);
    }
    if (!soft || !$('#dyroot')) $('#body').innerHTML = '<div id="dyroot"></div>';
    var root = $('#dyroot'), au = Dd.auto, days = Dd.days;
    if (!au || !days) { root.innerHTML = '<div class="card center"><div class="spin"></div></div>'; return; }
    var h = '';
    if (!au.on) {
      h += '<div class="card center" style="margin-top:6px"><div style="font-size:44px">🧭</div><h2 style="font-size:19px">' + T('روزانہ نقل و حرکت کا ریکارڈ', 'Daily movement record') + '</h2><p class="mut" style="margin-top:6px">' + tt('آن کریں تو ایپ خود ریکارڈ رکھتی ہے کہ آپ کہاں سے کہاں گئے، کتنا فاصلہ طے کیا، کتنا پیدل چلے اور کتنے قدم۔ سب کچھ صرف آپ کے فون میں رہتا ہے۔', 'Turn it on and the app keeps a record of where you went, how far, how much on foot and your steps. Everything stays on your phone.') + '</p><button class="btn" id="dyOn">' + T('روزانہ ریکارڈ شروع کریں', 'Start daily record') + '</button></div>';
    } else {
      h += '<div class="card" style="margin-top:6px"><div class="kv"><span>' + tt('روزانہ ریکارڈ', 'Daily record') + '</span><b style="color:var(--acc)">' + tt('جاری ● ', 'ON ● ') + '</b></div>' +
        (!au.bg ? '<p class="mut" style="font-size:12.5px;margin:6px 0">' + tt('⚠ ایپ بند ہونے پر بھی ریکارڈ کے لیے لوکیشن میں "ہر وقت اجازت دیں" (Allow all the time) چنیں۔', '⚠ For recording while the app is closed, choose "Allow all the time" for Location.') + '</p><button class="btn" id="dyBg" style="min-height:44px;font-size:15px">' + T('لوکیشن کی ترتیب کھولیں', 'Open location setting') + '</button>' : '') +
        (!au.activity ? '<p class="mut" style="font-size:12.5px;margin:6px 0">' + tt('قدم گننے کے لیے "جسمانی سرگرمی" کی اجازت دیں۔', 'Allow "Physical activity" to count steps.') + '</p><button class="btn" id="dyAct" style="min-height:44px;font-size:15px">' + T('اجازت دیں', 'Allow') + '</button>' : '') +
        '<div class="note" style="margin-top:10px;direction:ltr;text-align:start">' + (au.fixT ? tt('آخری لوکیشن: ', 'Last location: ') + Math.max(0, Math.round((Date.now() - au.fixT) / 60000)) + tt(' منٹ پہلے · ', ' min ago · ') + esc(au.fixProv || '') + ' · ' + au.fixAcc + ' m' : tt('ابھی تک کوئی لوکیشن نہیں ملی', 'No location received yet')) + (au.motion ? ' · ' + tt('حرکت سینسر: ', 'motion sensor: ') + au.motion : '') + ' · ' + (au.startT ? tt('سروس شروع: ', 'service started: ') + Math.round((Date.now() - au.startT) / 60000) + tt(' منٹ پہلے', ' min ago') : tt('سروس شروع نہیں ہوئی', 'service not started')) + '</div>' +
        (au.gpsEnabled === false ? '<div class="warn">' + tt('فون کی سیٹنگ میں لوکیشن (GPS) بند ہے، اسے آن کریں۔', 'Location (GPS) is turned off in phone settings; turn it on.') + '</div>' : '') +
        (au.err ? '<div class="warn">' + esc(au.err) + '</div>' : '') +
        (au.batteryOk === false ? '<div class="warn">' + tt('فون بیٹری بچت کے نام پر ایپ کو بند کر سکتا ہے۔ نیچے دبا کر Cleanova کو "Unrestricted / کوئی پابندی نہیں" کریں۔', 'The phone may stop the app to save battery. Tap below and set Cleanova to "Unrestricted".') + '</div><button class="btn" id="dyBat" style="min-height:44px;font-size:15px">' + T('بیٹری کی ترتیب کھولیں', 'Open battery setting') + '</button>' : '') +
        '<button class="btn" id="dyOff" style="background:var(--card2);color:var(--text);box-shadow:none;border:1px solid var(--line);min-height:44px;font-size:15px">' + T('ریکارڈ بند کریں', 'Stop recording') + '</button></div>';
    }
    var todayK = (function () { var d = new Date(); return d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0'); })();
    var today = days.filter(function (x) { return x.date === todayK; })[0], wk = 0, wkW = 0, wkS = 0, mo = 0, moS = 0, nowD = new Date(), weekAgo = Date.now() - 7 * 86400000;
    days.forEach(function (x) { var d = keyDate(x.date); if (d.getTime() >= weekAgo) { wk += x.distance; wkW += x.walk; wkS += x.steps; } if (d.getMonth() === nowD.getMonth() && d.getFullYear() === nowD.getFullYear()) { mo += x.distance; moS += x.steps; } });
    var td = today || { distance: 0, walk: 0, vehicle: 0, steps: au.stepsToday || 0, movingSec: 0 };
    h += '<div class="hero" style="display:block"><div class="k">' + T('آج', 'Today') + '</div><div class="big">' + km(td.distance) + '</div><div class="k" dir="ltr" style="font-size:13.5px;margin-top:6px;text-align:start">🚶 ' + km(td.walk) + ' · 🚗 ' + km(td.vehicle) + ' · 👣 ' + Math.round(td.steps || au.stepsToday || 0).toLocaleString('en') + ' · ⏱ ' + dur(td.movingSec * 1000) + '</div>' + (today ? '<button class="btn" id="dyToday">' + T('نقشے پر آج کا راستہ', "Today's route on map") + '</button>' : '') + '</div>';
    h += '<div class="card"><div class="kv"><span>' + tt('پچھلے 7 دن کل', 'Last 7 days') + '</span><b>' + km(wk) + '</b></div><div class="kv"><span>🚶 ' + tt('پیدل (7 دن)', 'On foot (7 days)') + '</span><b>' + km(wkW) + ' · ' + Math.round(wkS).toLocaleString('en') + ' 👣</b></div><div class="kv"><span>' + tt('اس مہینے کل', 'This month') + '</span><b>' + km(mo) + ' · ' + Math.round(moS).toLocaleString('en') + ' 👣</b></div></div>';
    h += '<div class="sec">' + tt('دن بہ دن', 'DAY BY DAY') + '</div>';
    if (!days.length) h += '<div class="card mut center">' + tt('ابھی کوئی ریکارڈ نہیں۔ ریکارڈ شروع کریں اور چند منٹ چلیں پھریں۔', 'No records yet. Start recording and move around for a few minutes.') + '</div>';
    days.forEach(function (x) { h += '<button class="cat" data-day="' + x.date + '"><span><b>' + dayLabel(x.date) + '</b><small class="e" dir="ltr" style="display:block;text-align:start">🚶 ' + km(x.walk) + ' · 🚗 ' + km(x.vehicle) + ' · 👣 ' + Math.round(x.steps).toLocaleString('en') + '</small></span><span style="direction:ltr;font-family:system-ui,sans-serif">' + km(x.distance) + '</span></button>'; });
    h += '<button class="cat" id="dyTrips" style="margin-top:14px"><span>📍 <b>' + tt('ٹرپس (ہاتھ سے شروع/ختم)', 'Trips (start/end by hand)') + '</b></span><span>›</span></button>';
    h += '<p class="mut" style="font-size:12px;margin:14px 4px">' + tt('پیدل اور گاڑی کا فرق رفتار سے لگایا جاتا ہے (تقریباً 8 km/h سے کم = پیدل)، اس لیے سائیکل یا تیز دوڑ میں کچھ فرق آ سکتا ہے۔ قدم فون کے قدم شمار کرنے والے سینسر سے آتے ہیں۔', 'Walking vs vehicle is judged by speed (under about 8 km/h = on foot), so cycling or fast running can be misjudged. Steps come from the phone step sensor.') + '</p>' + footer();
    root.innerHTML = h;
    var on = $('#dyOn'); if (on) on.onclick = function () {
      TP.locRequest().then(function (r) { if (!(r && r.granted)) { toast('لوکیشن کی اجازت نہیں ملی', 'Location permission denied'); throw new Error('x'); } return TP.permRequest({ which: 'activity' }); })
        .then(function () { return TP.permRequest({ which: 'bgloc' }); }).then(function () { return TP.autoSet({ on: true }); })
        .then(function () { toast('روزانہ ریکارڈ شروع', 'Daily record started'); vDays(); }).catch(function () { /* declined */ });
    };
    var off = $('#dyOff'); if (off) off.onclick = function () { TP.autoSet({ on: false }).then(function () { vDays(); }); };
    var bt = $('#dyBat'); if (bt) bt.onclick = function () { MP.batteryOptOpen().catch(function () { /* ignore */ }); };
    var bg = $('#dyBg'); if (bg) bg.onclick = function () { TP.permRequest({ which: 'bgloc' }).then(function () { vDays(); }); };
    var ac = $('#dyAct'); if (ac) ac.onclick = function () { TP.permRequest({ which: 'activity' }).then(function () { vDays(); }); };
    var tb = $('#dyToday'); if (tb) tb.onclick = function () { S.day = { date: todayK }; go('day'); };
    var tr = $('#dyTrips'); if (tr) tr.onclick = function () { S.tr = null; go('trips'); };
    [].forEach.call(document.querySelectorAll('[data-day]'), function (b) { b.onclick = function () { S.day = { date: b.dataset.day }; go('day'); }; });
  }
  var mapObj = null;
  function vDay() {
    var D = S.day = S.day || {};
    setTop(T('دن کا نقشہ', 'Day map'));
    if (!D.det && !D.loading) { D.loading = true; TP.dayDetail({ date: D.date }).then(function (r) { D.det = r; D.loading = false; if (S.view === 'day') vDay(); }).catch(function () { D.loading = false; D.det = { route: [], stops: [], journeys: [], distance: 0, walk: 0, vehicle: 0, steps: 0, movingSec: 0 }; if (S.view === 'day') vDay(); }); }
    var d = D.det;
    if (!d) { $('#body').innerHTML = '<div class="card center"><div class="spin"></div></div>'; return; }
    var rt = d.route || [], style = D.style || store('mapStyle') || 'osm';
    var h = '<div class="card" style="margin-top:6px;padding:0;overflow:hidden"><div id="map" style="height:330px;border-radius:20px 20px 0 0;background:#e8e4dc"></div>' +
      '<div style="position:absolute;margin-top:-100px;inset-inline-end:10px;display:flex;flex-direction:column;gap:6px" id="mapbtns"><button class="iconbtn" id="mZin" style="font-size:22px">+</button><button class="iconbtn" id="mZout" style="font-size:22px">−</button><button class="iconbtn" id="mFit" aria-label="fit">⌖</button></div>' +
      '<div style="padding:10px 12px"><div class="chips" style="margin-top:0"><button class="chip' + (style === 'osm' ? ' on' : '') + '" data-ms="osm">' + tt('عام نقشہ', 'Standard') + '</button><button class="chip' + (style === 'carto' ? ' on' : '') + '" data-ms="carto">' + tt('ہلکا نقشہ', 'Light') + '</button><button class="chip" id="mKhi">' + tt('کراچی آف لائن', 'Save Karachi offline') + '</button></div>' +
      '<div class="mut" style="font-size:12px;margin-top:6px"><span style="color:#1a73e8">┅</span> ' + tt('پیدل', 'On foot') + ' &nbsp; <span style="color:#e5484d">━</span> ' + tt('گاڑی', 'Vehicle') + ' &nbsp; <span style="color:#34c48b">●</span> ' + tt('آغاز', 'Start') + ' &nbsp; <span style="color:#ef7b6c">●</span> ' + tt('اختتام', 'End') + ' &nbsp; <span style="color:#f59f00">●</span> ' + tt('ٹھہراؤ', 'Stop') + '</div><div id="mKhiP" class="mut" style="font-size:12px"></div></div></div>';
    h += '<div class="card"><b style="font-size:17px">' + dayLabel(D.date) + '</b><div class="kv" style="margin-top:6px"><span>' + tt('کل فاصلہ', 'Total distance') + '</span><b>' + km(d.distance) + '</b></div><div class="kv"><span>🚶 ' + tt('پیدل', 'On foot') + '</span><b>' + km(d.walk) + '</b></div><div class="kv"><span>🚗 ' + tt('گاڑی میں', 'By vehicle') + '</span><b>' + km(d.vehicle) + '</b></div><div class="kv"><span>👣 ' + tt('قدم', 'Steps') + '</span><b>' + Math.round(d.steps || 0).toLocaleString('en') + '</b></div><div class="kv"><span>⏱ ' + tt('چلنے کا وقت', 'Time moving') + '</span><b>' + dur(d.movingSec * 1000) + '</b></div></div>';
    if (d.journeys && d.journeys.length) {
      h += '<div class="sec">' + tt('کہاں سے کہاں', 'WHERE FROM, WHERE TO') + '</div>' + d.journeys.map(function (j, i) {
        return '<div class="card"><div style="font-size:15px;line-height:1.9"><b>' + nm(j.fromLat, j.fromLon) + '</b> ← <b>' + nm(j.toLat, j.toLon) + '</b></div><div class="mut" style="font-size:12.5px;direction:ltr;text-align:start">' + tclock(j.t0) + ' – ' + tclock(j.t1) + ' · ' + km(j.walk + j.vehicle) + ' · ' + (j.walk > j.vehicle ? '🚶' : '🚗') + '</div><button class="chip" data-gm="' + i + '" style="margin-top:6px">' + tt('Google Maps میں راستہ', 'Directions in Google Maps') + '</button></div>';
      }).join('');
    }
    if (d.stops && d.stops.length) {
      h += '<div class="sec">' + tt('ٹھہراؤ (10 منٹ سے زیادہ)', 'STOPS (10+ MINUTES)') + '</div><div class="card">' + d.stops.map(function (x, i) { return '<div class="kv"><span>📍 ' + nm(x.lat, x.lon) + '</span><b>' + tclock(x.t0) + ' – ' + tclock(x.t1) + ' · ' + dur(x.t1 - x.t0) + ' <button class="chip" data-gs="' + i + '" style="padding:0 8px">↗</button> <button class="chip" data-pnm="' + i + '" style="padding:0 8px">✎</button></b></div>'; }).join('') + '</div>';
    }
    h += '<div class="card"><button class="btn" id="dyDel" style="background:var(--red);color:#fff;box-shadow:none;margin-top:0">' + T('اس دن کا ریکارڈ حذف کریں', 'Delete this day') + '</button></div>' + footer();
    $('#body').innerHTML = h;
    /* map */
    var pts = rt.map(function (p) { return [p.lat, p.lon]; });
    mapObj = new window.TileMap($('#map'), { style: style, lat: 24.8607, lon: 67.0011, zoom: 11 });
    var draw = function () {
      var layers = [], cur = null;
      rt.forEach(function (p, i) { if (!i) return; var m = p.m; if (!m) { cur = null; return; } if (!cur || cur.m !== m) { cur = { type: 'line', m: m, pts: [[rt[i - 1].lat, rt[i - 1].lon]], color: m === 1 ? '#1a73e8' : '#e5484d', w: m === 1 ? 4 : 5, dash: m === 1 ? [1, 8] : null }; layers.push(cur); } cur.pts.push([p.lat, p.lon]); });
      (d.stops || []).forEach(function (x) { layers.push({ type: 'dot', lat: x.lat, lon: x.lon, color: '#f59f00', r: 8, label: PN[pkey(x.lat, x.lon)] || (pname(x.lat, x.lon), '') }); });
      if (rt.length) { layers.push({ type: 'dot', lat: rt[0].lat, lon: rt[0].lon, color: '#34c48b', r: 8 }); layers.push({ type: 'dot', lat: rt[rt.length - 1].lat, lon: rt[rt.length - 1].lon, color: '#ef7b6c', r: 8 }); }
      mapObj.setLayers(layers);
    };
    S.dayRedraw = function () { if (S.view !== 'day') return; draw(); };
    draw(); if (pts.length) mapObj.fit(pts, 36);
    $('#mZin').onclick = function () { mapObj.zoomBy(1); }; $('#mZout').onclick = function () { mapObj.zoomBy(-1); }; $('#mFit').onclick = function () { if (pts.length) mapObj.fit(pts, 36); else { mapObj.lat = 24.8607; mapObj.lon = 67.0011; mapObj.z = 11; mapObj.draw(); } };
    [].forEach.call(document.querySelectorAll('[data-ms]'), function (b) { b.onclick = function () { D.style = b.dataset.ms; store('mapStyle', D.style); mapObj.setStyle(D.style); [].forEach.call(document.querySelectorAll('[data-ms]'), function (x) { x.classList.toggle('on', x === b); }); }; });
    $('#mKhi').onclick = function () {
      var p = $('#mKhiP'), b = $('#mKhi'); b.disabled = true;
      window.TileMap.preload(D.style || style, [25.08, 66.88, 24.78, 67.36], 10, 14, function (i, n) { p.textContent = tt('محفوظ ہو رہا ہے: ', 'Saving: ') + i + ' / ' + n; }).then(function (r) { p.textContent = tt('کراچی کا نقشہ محفوظ ہو گیا (' + r.ok + ' ٹائلز)', 'Karachi map saved (' + r.ok + ' tiles)'); b.disabled = false; });
    };
    [].forEach.call(document.querySelectorAll('[data-gm]'), function (b) { b.onclick = function () { var j = d.journeys[+b.dataset.gm]; gmaps({ from: [j.fromLat, j.fromLon], to: [j.toLat, j.toLon] }); }; });
    [].forEach.call(document.querySelectorAll('[data-gs]'), function (b) { b.onclick = function () { var x = d.stops[+b.dataset.gs]; gmaps({ at: [x.lat, x.lon] }); }; });
    [].forEach.call(document.querySelectorAll('[data-pnm]'), function (b) { b.onclick = function () { var x = d.stops[+b.dataset.pnm]; CL.ask(tt('اس جگہ کا نام', 'Name this place'), '', function (v) { CL.savePlace(v, x.lat, x.lon); vDay(); }, tt('گھر، آفس، مسجد…', 'Home, office, mosque…')); }; });
    $('#dyDel').onclick = function () { var b = $('#dyDel'); if (!b.dataset.sure) { b.dataset.sure = '1'; b.innerHTML = T('تصدیق کے لیے دوبارہ دبائیں', 'Tap again to confirm'); return; } TP.dayDelete({ date: D.date }).then(function () { S.day = null; if (S.dl) S.dl.days = null; goBack(); }); };
  }

  /* ---------- personal trip log ---------- */
  var TP = (Cap && Cap.Plugins && Cap.Plugins.Travel && !window.CLEANOVA_MOCK) ? Cap.Plugins.Travel : window.TravelMock;
  var tripTimer = 0;
  var liveW = null;
  function stopLive() { if (liveW != null && navigator.geolocation) { try { navigator.geolocation.clearWatch(liveW); } catch (e) { /* ignore */ } } liveW = null; }
  function liveSpeed(Tt) {
    if (liveW != null || !navigator.geolocation) return;
    liveW = navigator.geolocation.watchPosition(function (p) {
      var v = p.coords.speed; if (v == null || isNaN(v) || (p.coords.accuracy || 0) > 60) return;
      Tt.liveSp = v < 0.6 ? 0 : v; var e = document.getElementById('trsp'); if (e) e.textContent = Math.round(Tt.liveSp * 3.6) + ' km/h';
    }, function () { /* no fix yet */ }, { enableHighAccuracy: true, maximumAge: 2000, timeout: 20000 });
  }
  function clearTrip() { stopLive(); if (tripTimer) { clearInterval(tripTimer); tripTimer = 0; } }
  function km(m) { return m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(m < 10000 ? 2 : 1) + ' km'; }
  function tclock(t) { var d = new Date(t); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  function tdate(t) { return '<bdi dir="ltr">' + new Date(t).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + ' · ' + tclock(t) + '</bdi>'; }
  function routeSvg(pts) {
    if (!pts || pts.length < 2) return '<div class="mut center" style="padding:30px">' + tt('راستہ بنانے کے لیے ابھی کافی پوائنٹس نہیں۔', 'Not enough points to draw a route yet.') + '</div>';
    var W = 300, H = 200, pad = 16, lat0 = pts[0].lat, k = Math.cos(lat0 * Math.PI / 180), xs = pts.map(function (p) { return p.lon * k; }), ys = pts.map(function (p) { return p.lat; });
    var x0 = Math.min.apply(null, xs), x1 = Math.max.apply(null, xs), y0 = Math.min.apply(null, ys), y1 = Math.max.apply(null, ys), sc = Math.min((W - 2 * pad) / Math.max(1e-9, x1 - x0), (H - 2 * pad) / Math.max(1e-9, y1 - y0));
    var ox = (W - (x1 - x0) * sc) / 2, oy = (H - (y1 - y0) * sc) / 2;
    var P = pts.map(function (p, i) { return [(xs[i] - x0) * sc + ox, H - ((ys[i] - y0) * sc + oy)]; });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;height:210px;background:var(--bg);border-radius:14px;direction:ltr"><polyline points="' + P.map(function (q) { return q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' ') + '" fill="none" stroke="var(--acc)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="' + P[0][0].toFixed(1) + '" cy="' + P[0][1].toFixed(1) + '" r="6" fill="#34c48b" stroke="#fff" stroke-width="2"/><circle cx="' + P[P.length - 1][0].toFixed(1) + '" cy="' + P[P.length - 1][1].toFixed(1) + '" r="6" fill="#ef7b6c" stroke="#fff" stroke-width="2"/></svg>';
  }
  function vTrips(soft) {
    setTop(T('سفر کا ریکارڈ', 'Travel log'));
    var Tt = S.tr = S.tr || {};
    if (!soft) {
      clearTrip(); Tt.loading = true;
      var load = function () {
        TP.locStatus().then(function (r) { Tt.perm = !!(r && r.granted); });
        TP.tripConfig({}).then(function (r) { Tt.limit = r && r.dataLimitMb || 0; }).catch(function () { /* old build */ });
        if (!Tt.snap) { MP.snapshot().then(function (r) { Tt.snap = r; }).catch(function () { /* optional */ }); MP.usageStatus().then(function (r) { Tt.ug = !!(r && r.granted); }).catch(function () { /* optional */ }); }
        TP.tripStatus().then(function (r) { Tt.status = r; });
        TP.tripList().then(function (r) { Tt.list = (r && r.trips) || []; Tt.loading = false; if (S.view === 'trips') vTrips(true); }).catch(function () { Tt.loading = false; Tt.list = []; if (S.view === 'trips') vTrips(true); });
      };
      load(); tripTimer = setInterval(function () { if (S.view !== 'trips') return clearTrip(); load(); }, 6000);
    }
    var body = $('#body'); if (!soft || !$('#trroot')) body.innerHTML = '<div id="trroot"></div>';
    var root = $('#trroot'), list = Tt.list;
    if (!list) { root.innerHTML = '<div class="card center"><div class="spin"></div></div>'; return; }
    var st = Tt.status || {}, h = '';
    if (st.active) {
      var t = st.trip || {}, el = Math.max(0, Date.now() - (t.start || Date.now()));
      h += '<div class="hero" style="display:block;margin-top:6px"><div class="k">' + T('سفر ریکارڈ ہو رہا ہے ●', 'Recording trip ●') + '</div><div class="big">' + km(t.distance || 0) + '</div><div class="k" style="font-size:13px">' + dur(el) + ' · ' + (t.points || 0) + ' ' + tt('پوائنٹس', 'points') + '</div><div class="kv" style="margin-top:8px"><span>🚗 ' + tt('ابھی رفتار', 'Speed now') + '</span><b id="trsp" style="direction:ltr;font-size:22px">' + (Tt.liveSp == null ? '–' : Math.round(Tt.liveSp * 3.6)) + ' km/h</b></div><div class="kv"><span>' + tt('زیادہ سے زیادہ', 'Top speed') + '</span><b style="direction:ltr">' + Math.round((t.maxSpeed || 0) * 3.6) + ' km/h</b></div><div class="kv"><span>' + tt('اوسط', 'Average') + '</span><b style="direction:ltr">' + (el > 5000 ? (((t.distance || 0) / (el / 1000)) * 3.6).toFixed(1) : '0') + ' km/h</b></div><button class="btn o" id="trBig" style="margin-top:8px">' + T('رفتار کا بڑا ڈسپلے', 'Big speedometer') + '</button><button class="btn" id="trStop" style="background:var(--red);color:#fff;box-shadow:none">' + T('سفر ختم کریں', 'End trip') + '</button></div>';
    } else if (!Tt.perm) {
      h += '<div class="card center" style="margin-top:6px"><div style="font-size:44px">🧭</div><h2 style="font-size:19px">' + T('لوکیشن کی اجازت', 'Location permission') + '</h2><p class="mut" style="margin-top:6px">' + tt('سفر کا راستہ، فاصلہ اور وقت ریکارڈ کرنے کے لیے لوکیشن چاہیے۔ ریکارڈ صرف آپ کے فون میں رہتا ہے، کہیں اپلوڈ نہیں ہوتا، اور صرف تب بنتا ہے جب آپ خود "سفر شروع" دبائیں۔', 'Location is needed to record your route, distance and time. It stays on your phone, is never uploaded, and only records after you tap "Start trip".') + '</p><button class="btn" id="trPerm">' + T('اجازت دیں', 'Allow location') + '</button></div>';
    } else {
      h += '<div class="card" style="margin-top:6px"><input id="trName" placeholder="' + tt('سفر کا نام (اختیاری)، مثلاً لاہور ٹرپ', 'Trip name (optional), e.g. Lahore trip') + '" style="width:100%;min-height:46px;border-radius:14px;border:1px solid var(--line);background:var(--bg);color:var(--text);padding:0 12px;font-size:15px"><button class="btn" id="trStart">' + T('سفر شروع کریں', 'Start trip') + '</button><p class="mut" style="font-size:12px;margin-top:8px">' + tt('ریکارڈنگ کے دوران اوپر ایک نوٹیفکیشن رہتا ہے۔ بیٹری بچانے کے لیے ختم کرنا نہ بھولیں۔', 'A notification stays on while recording. Remember to end the trip to save battery.') + '</p></div>';
    }
    if (!st.active && Tt.perm) {
      var sn = Tt.snap, fb = sn && sn.storage ? sn.storage.free : 0, bl = sn && sn.battery ? sn.battery.level : null;
      var ck = function (ok, txt, hint) { return '<div class="kv"><span>' + (ok === null ? '⏳' : ok ? '✅' : '⚠️') + ' ' + txt + '</span><b style="font-size:12.5px;color:var(--mut)">' + (hint || '') + '</b></div>'; };
      h += '<div class="sec">' + tt('سفر سے پہلے کی چیک لسٹ', 'BEFORE YOU TRAVEL') + '</div><div class="card">' +
        ck(bl === null ? null : bl >= 80, tt('بیٹری کم از کم 80%', 'Battery at least 80%'), bl === null ? '' : bl + '%') +
        ck(fb ? fb >= 5e9 : null, tt('اسٹوریج میں 5 GB خالی', '5 GB free storage'), fb ? fmt(fb) : '') +
        ck(Tt.perm, tt('لوکیشن کی اجازت', 'Location permission'), '') +
        ck(Tt.ug === undefined ? null : Tt.ug, tt('ڈیٹا کی نگرانی (Usage access)', 'Data tracking (Usage access)'), Tt.ug ? '' : tt('مانیٹر ٹیب سے دیں', 'grant in Monitor')) +
        (fb ? '<div class="sec" style="margin:12px 0 4px">' + tt('خالی جگہ میں تقریباً', 'FREE SPACE FITS ABOUT') + '</div><div class="kv"><span>📷 ' + tt('تصاویر', 'Photos') + '</span><b>' + Math.floor(fb / 4e6).toLocaleString('en') + '</b></div><div class="kv"><span>🎬 1080p ' + tt('ویڈیو', 'video') + '</span><b>' + Math.floor(fb / 130e6 / 60) + ' ' + tt('گھنٹے', 'h') + '</b></div><div class="kv"><span>🎬 4K ' + tt('ویڈیو', 'video') + '</span><b>' + Math.floor(fb / 375e6 / 60) + ' ' + tt('گھنٹے', 'h') + '</b></div>' : '') +
        '<div class="sec" style="margin:12px 0 4px">' + tt('سفر میں موبائل ڈیٹا کی حد (الرٹ)', 'MOBILE DATA LIMIT FOR A TRIP (ALERT)') + '</div><div class="chips">' + [[0, tt('بند', 'Off')], [500, '500 MB'], [1024, '1 GB'], [2048, '2 GB'], [5120, '5 GB']].map(function (c) { return '<button class="chip' + ((Tt.limit || 0) === c[0] ? ' on' : '') + '" data-dl="' + c[0] + '">' + c[1] + '</button>'; }).join('') + '</div></div>';
    }
    var now = new Date(), ms = new Date(now.getFullYear(), now.getMonth(), 1).getTime(), mt = 0, mc = 0;
    list.forEach(function (x) { if (x.start >= ms) { mt += x.distance; mc++; } });
    h += '<div class="card"><div class="kv"><span>' + tt('اس مہینے سفر', 'Trips this month') + '</span><b>' + mc + '</b></div><div class="kv"><span>' + tt('اس مہینے کا کل فاصلہ', 'Distance this month') + '</span><b>' + km(mt) + '</b></div></div>';
    h += '<div class="sec">' + tt('میرے سفر', 'MY TRIPS') + '</div>';
    if (!list.length) h += '<div class="card mut center">' + tt('ابھی کوئی سفر ریکارڈ نہیں۔', 'No trips recorded yet.') + '</div>';
    list.forEach(function (x) {
      h += '<button class="cat" data-trip="' + x.id + '"><span><b>' + (x.roamed ? '🌍 ' : '') + (x.name || tdate(x.start)) + '</b>' + (x.name ? '<small class="e" style="display:block">' + tdate(x.start) + '</small>' : '') + '</span><span style="direction:ltr;font-family:system-ui,sans-serif">' + km(x.distance) + ' · ' + dur(Math.max(0, x.end - x.start)) + '</span></button>';
    });
    h += '<p class="mut" style="font-size:12px;margin:14px 4px">' + tt('نقشے کی جگہ راستے کا خاکہ دکھایا جاتا ہے، تاکہ سب کچھ بغیر انٹرنیٹ کے بھی چلے۔ GPX فائل کسی بھی نقشے کی ایپ میں کھل سکتی ہے۔', 'A route sketch is shown instead of map tiles so everything works offline. The GPX file opens in any maps app.') + '</p>' + footer();
    root.innerHTML = h;
    [].forEach.call(document.querySelectorAll('[data-dl]'), function (b) { b.onclick = function () { TP.tripConfig({ dataLimitMb: +b.dataset.dl }).then(function (r) { Tt.limit = r.dataLimitMb; vTrips(true); }); }; });
    var ps = $('#trPerm'); if (ps) ps.onclick = function () { TP.locRequest().then(function (r) { Tt.perm = !!(r && r.granted); if (!Tt.perm) toast('اجازت نہیں ملی', 'Permission not granted'); vTrips(true); }); };
    var sb = $('#trStart'); if (sb) sb.onclick = function () { TP.tripStart({ name: ($('#trName').value || '').trim() }).then(function () { Tt.status = { active: true, trip: { start: Date.now(), distance: 0, points: 0 } }; vTrips(true); toast('ریکارڈنگ شروع', 'Recording started'); }).catch(function (e) { toast('شروع نہیں ہو سکا', 'Could not start: ' + (e && e.message || e)); }); };
    var bg = $('#trBig'); if (bg) bg.onclick = function () { go('speed'); };
    if (st.active) liveSpeed(Tt); else stopLive();
    var eb = $('#trStop'); if (eb) eb.onclick = function () { TP.tripStop().then(function () { Tt.status = { active: false }; return TP.tripList(); }).then(function (r) { Tt.list = (r && r.trips) || []; vTrips(true); toast('سفر محفوظ ہو گیا', 'Trip saved'); }); };
    [].forEach.call(document.querySelectorAll('[data-trip]'), function (b) { b.onclick = function () { S.trip = { id: +b.dataset.trip }; go('trip'); }; });
  }
  function vTrip() {
    setTop(T('سفر کی تفصیل', 'Trip details'));
    var D = S.trip = S.trip || {}, tr = ((S.tr && S.tr.list) || []).filter(function (x) { return x.id === D.id; })[0];
    if (!tr) { $('#body').innerHTML = '<div class="card mut center">' + tt('سفر نہیں ملا۔', 'Trip not found.') + '</div>'; return; }
    if (!D.pts && !D.loading) {
      D.loading = true;
      TP.tripPoints({ id: tr.id }).then(function (r) { D.pts = (r && r.points) || []; D.loading = false; if (S.view === 'trip') vTrip(); });
      TP.tripDetail({ id: tr.id }).then(function (r) { D.det = r; if (S.view === 'trip') vTrip(); }).catch(function () { /* old build */ });
      TP.extraGet({ id: tr.id }).then(function (r) { try { D.extra = JSON.parse(r.json || '[]'); } catch (x) { D.extra = []; } if (S.view === 'trip') vTrip(); }).catch(function () { D.extra = []; });
      if (tr.points) { TP.placeName({ lat: tr.lat0, lon: tr.lon0 }).then(function (r) { D.from = r && r.name; if (S.view === 'trip') vTrip(); }).catch(function () { /* offline */ });
        TP.placeName({ lat: tr.lat1, lon: tr.lon1 }).then(function (r) { D.to = r && r.name; if (S.view === 'trip') vTrip(); }).catch(function () { /* offline */ }); }
    }
    var secs = Math.max(1, (tr.end - tr.start) / 1000), avg = tr.distance / secs * 3.6;
    var h = '<div class="card" style="margin-top:6px"><b style="font-size:17px">' + (tr.name || tdate(tr.start)) + '</b><div class="mut" style="font-size:12.5px">' + tdate(tr.start) + ' → <bdi dir="ltr">' + tclock(tr.end) + '</bdi></div>' + (D.pts ? routeSvg(D.pts) : '<div class="center" style="padding:30px"><div class="spin"></div></div>') +
      ((D.from || D.to) ? '<div class="kv" style="margin-top:8px"><span>🟢 ' + tt('سے', 'From') + '</span><b style="direction:rtl">' + (D.from || '–') + '</b></div><div class="kv"><span>🔴 ' + tt('تک', 'To') + '</span><b style="direction:rtl">' + (D.to || '–') + '</b></div>' : '') + '</div>';
    h += '<div class="card"><div class="kv"><span>' + tt('فاصلہ', 'Distance') + '</span><b>' + km(tr.distance) + '</b></div><div class="kv"><span>' + tt('دورانیہ', 'Duration') + '</span><b>' + dur(tr.end - tr.start) + '</b></div><div class="kv"><span>' + tt('اوسط رفتار', 'Average speed') + '</span><b>' + avg.toFixed(1) + ' km/h</b></div><div class="kv"><span>' + tt('زیادہ سے زیادہ رفتار', 'Top speed') + '</span><b>' + Math.round(tr.maxSpeed * 3.6) + ' km/h</b></div><div class="kv"><span>' + tt('ریکارڈ شدہ پوائنٹس', 'Recorded points') + '</span><b>' + tr.points + '</b></div></div>';
    if (D.pts && D.pts.length > 3) {
      var sps = D.pts.map(function (q) { return (q.sp || 0) * 3.6; }), smx = Math.max.apply(null, sps) || 1, sw = 300, sh = 70;
      var sd = sps.map(function (v, i) { return (i ? 'L' : 'M') + (i / (sps.length - 1) * sw).toFixed(1) + ' ' + (sh - v / smx * (sh - 6) - 3).toFixed(1); }).join(' ');
      h += '<div class="card"><b>' + tt('سفر میں رفتار', 'Speed during the trip') + '</b><svg viewBox="0 0 ' + sw + ' ' + sh + '" style="width:100%;height:80px;margin-top:6px;direction:ltr"><path d="' + sd + '" fill="none" stroke="#38bdf8" stroke-width="2"/></svg><div class="kv"><span>' + tt('سب سے تیز', 'Fastest') + '</span><b style="direction:ltr">' + Math.round(smx) + ' km/h</b></div></div>';
    }
    var dt = D.det || {}, ex = D.extra || [], spent = 0;
    ex.forEach(function (e) { if (e.k === 'e') spent += +e.a || 0; });
    h += '<div class="card">' +
      (dt.bat0 != null && dt.bat1 != null ? '<div class="kv"><span>🔋 ' + tt('بیٹری', 'Battery') + '</span><b>' + dt.bat0 + '% → ' + dt.bat1 + '%</b></div>' : '') +
      (dt.dataMobile != null ? '<div class="kv"><span>📶 ' + tt('موبائل ڈیٹا', 'Mobile data') + '</span><b>' + (dt.dataMobile >= 0 ? fmt(dt.dataMobile) : '–') + '</b></div><div class="kv"><span>📡 Wi-Fi</span><b>' + (dt.dataWifi >= 0 ? fmt(dt.dataWifi) : '–') + '</b></div>' : '<div class="mut" style="font-size:12px;padding:6px 0">' + tt('ڈیٹا کا استعمال دیکھنے کے لیے مانیٹر میں Usage access دیں۔', 'Grant Usage access in Monitor to see data use.') + '</div>') +
      (dt.photos != null ? '<div class="kv"><span>📷 ' + tt('تصاویر / ویڈیوز', 'Photos / videos') + '</span><b>' + dt.photos + ' / ' + dt.videos + '</b></div>' : '') +
      (tr.roamed ? '<div class="kv"><span>🌍 ' + tt('رومنگ', 'Roaming') + '</span><b>' + tt('ہاں', 'Yes') + '</b></div>' : '') + '</div>';
    if (dt.stops && dt.stops.length) h += '<div class="card"><div class="sec" style="margin:0 0 6px">' + tt('رکنے کی جگہیں (10 منٹ سے زیادہ)', 'STOPS (10+ MINUTES)') + '</div>' + dt.stops.map(function (x) { return '<div class="kv"><span>📍 ' + tclock(x.t0) + ' – ' + tclock(x.t1) + '</span><b>' + dur(x.t1 - x.t0) + '</b></div>'; }).join('') + '</div>';
    h += '<div class="card"><div class="sec" style="margin:0 0 6px">' + tt('نوٹس اور خرچ', 'NOTES AND EXPENSES') + '</div>' + ex.map(function (e, i) { return '<div class="kv"><span>' + (e.k === 'e' ? '💵 ' : '📝 ') + e.x + '</span><b>' + (e.k === 'e' ? (+e.a).toLocaleString('en') : '') + ' <button class="chip" data-xdel="' + i + '" style="padding:0 8px">✕</button></b></div>'; }).join('') +
      (spent ? '<div class="kv"><span><b>' + tt('کل خرچ', 'Total spent') + '</b></span><b style="color:var(--acc)">' + spent.toLocaleString('en') + '</b></div>' : '') +
      '<input id="xTxt" placeholder="' + tt('نوٹ یا خرچ کی تفصیل', 'Note or expense detail') + '" style="width:100%;margin-top:8px;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--bg);color:var(--text);padding:0 12px;font-size:15px"><input id="xAmt" type="number" inputmode="decimal" placeholder="' + tt('رقم (خرچ کے لیے)', 'Amount (for expenses)') + '" style="width:100%;margin-top:8px;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--bg);color:var(--text);padding:0 12px;font-size:15px"><button class="btn" id="xAdd" style="min-height:44px;font-size:15px">' + T('شامل کریں', 'Add') + '</button></div>';
    h += '<div class="card"><input id="trRen" value="' + (tr.name || '').replace(/"/g, '&quot;') + '" placeholder="' + tt('نام بدلیں', 'Rename') + '" style="width:100%;min-height:44px;border-radius:12px;border:1px solid var(--line);background:var(--bg);color:var(--text);padding:0 12px;font-size:15px"><button class="btn" id="trSaveName" style="min-height:44px;font-size:15px;background:var(--card2);color:var(--text);box-shadow:none;border:1px solid var(--line)">' + T('نام محفوظ کریں', 'Save name') + '</button><button class="btn" id="trExp">' + T('GPX فائل بنائیں', 'Export GPX file') + '</button><button class="btn" id="trDel" style="background:var(--red);color:#fff;box-shadow:none">' + T('یہ سفر حذف کریں', 'Delete this trip') + '</button></div>' + footer();
    $('#body').innerHTML = h;
    var save = function () { TP.extraSet({ id: tr.id, json: JSON.stringify(D.extra || []) }); vTrip(); };
    $('#xAdd').onclick = function () { var x = $('#xTxt').value.trim(), a = $('#xAmt').value; if (!x && !a) return; D.extra = D.extra || []; D.extra.push({ k: a ? 'e' : 'n', x: x || tt('خرچ', 'Expense'), a: +a || 0, t: Date.now() }); save(); };
    [].forEach.call(document.querySelectorAll('[data-xdel]'), function (b) { b.onclick = function () { D.extra.splice(+b.dataset.xdel, 1); save(); }; });
    $('#trSaveName').onclick = function () { TP.tripRename({ id: tr.id, name: $('#trRen').value.trim() }).then(function () { tr.name = $('#trRen').value.trim(); toast('نام محفوظ', 'Name saved'); vTrip(); }); };
    $('#trExp').onclick = function () { TP.tripExport({ id: tr.id }).then(function (r) { toast('محفوظ: ' + r.path.replace('/storage/emulated/0/', ''), 'Saved: ' + r.path.replace('/storage/emulated/0/', '')); }).catch(function (e) { toast('فائل نہیں بنی', 'Export failed: ' + (e && e.message || e)); }); };
    var db = $('#trDel'); db.onclick = function () { if (!db.dataset.sure) { db.dataset.sure = '1'; db.innerHTML = T('تصدیق کے لیے دوبارہ دبائیں', 'Tap again to confirm'); return; } TP.tripDelete({ id: tr.id }).then(function () { S.tr.list = S.tr.list.filter(function (x) { return x.id !== tr.id; }); S.trip = null; goBack(); }); };
  }

  /* ---------- phone monitor ---------- */
  var MP = (Cap && Cap.Plugins && Cap.Plugins.Monitor && !window.CLEANOVA_MOCK) ? Cap.Plugins.Monitor : window.MonitorMock;
  var monTimer = 0;
  function clearMon() { if (monTimer) { clearInterval(monTimer); monTimer = 0; } }
  function dur(ms) {
    var m = Math.round(ms / 60000), h = Math.floor(m / 60); m = m % 60;
    if (!h && !m) return PREF.lang === 'en' ? '<1 min' : '1 منٹ سے کم';
    return PREF.lang === 'en' ? (h ? h + 'h ' : '') + m + 'm' : (h ? h + ' گھنٹے ' : '') + (m ? m + ' منٹ' : '');
  }
  function monBars(vals, fmtv, color) {
    var mx = Math.max.apply(null, vals.concat([1])), nm = PREF.lang === 'en' ? ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'] : ['اتو', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ'], d = new Date(), h = '<div class="mcols">';
    vals.forEach(function (v, i) {
      var dd = new Date(d.getTime() - (vals.length - 1 - i) * 86400000);
      h += '<div class="mc"><span class="mv">' + (v ? fmtv(v) : '') + '</span><i style="height:' + Math.max(3, Math.round(v / mx * 70)) + 'px;background:' + (color || 'var(--acc)') + (i === vals.length - 1 ? '' : ';opacity:.55') + '"></i><span class="ml">' + nm[dd.getDay()] + '</span></div>';
    });
    return h + '</div>';
  }
  function spark(samples) {
    if (samples.length < 2) return '<div class="mut" style="font-size:12px;margin-top:8px">' + tt('ہسٹری بننے میں کچھ وقت لگے گا، ایپ کھولتے رہیں۔', 'History builds up as you open the app.') + '</div>';
    var t0 = samples[0].t, t1 = samples[samples.length - 1].t, W = 300, H = 60, span = Math.max(1, t1 - t0);
    var pts = samples.map(function (s) { return ((s.t - t0) / span * W).toFixed(1) + ',' + (H - s.l / 100 * H).toFixed(1); }).join(' ');
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;height:64px;margin-top:8px;direction:ltr"><polyline points="' + pts + '" fill="none" stroke="var(--acc)" stroke-width="2.2" stroke-linejoin="round"/></svg><div class="mut" style="font-size:11px;display:flex;justify-content:space-between;direction:ltr"><span>' + (span > 129600000 ? Math.round(span / 86400000) + 'd' : Math.max(1, Math.round(span / 3600000)) + 'h') + '</span><span>' + tt('اب', 'now') + '</span></div>';
  }
  function recordBat(level) {
    try {
      var a = JSON.parse(localStorage.getItem('cl.bat') || '[]'), now = Date.now();
      if (!a.length || now - a[a.length - 1].t > 5 * 60000) { a.push({ t: now, l: level }); a = a.filter(function (x) { return now - x.t < 86400000; }); localStorage.setItem('cl.bat', JSON.stringify(a)); }
      return a;
    } catch (e) { return []; }
  }
  function loadMon(full) {
    var M = S.mon = S.mon || {};
    MP.snapshot().then(function (s) { M.snap = s; if (S.view === 'monitor') vMonitor(true); }).catch(function () { M.err = true; if (S.view === 'monitor') vMonitor(true); });
    if (!full) { MP.history().then(function (r) { M.hist = (r && r.points) || []; }).catch(function () { /* no history */ }); return; }
    MP.monitorStatus().then(function (r) { M.mon = r; if (S.view === 'monitor') vMonitor(true); }).catch(function () { /* old build */ });
    MP.history().then(function (r) { M.hist = (r && r.points) || []; if (S.view === 'monitor') vMonitor(true); }).catch(function () { /* no history */ });
    MP.usageStatus().then(function (r) {
      M.ug = !!(r && r.granted);
      if (S.view === 'monitor') vMonitor(true);
      if (!M.ug) return;
      MP.usage().then(function (u) { M.usage = u; if (S.view === 'monitor') vMonitor(true); }).catch(function () { M.usageErr = true; });
      MP.unusedApps({ days: 30 }).then(function (u) { M.unused = u; if (S.view === 'monitor') vMonitor(true); }).catch(function () { /* optional */ });
      MP.dataUsage().then(function (u) { M.data = u; if (S.view === 'monitor') vMonitor(true); }).catch(function () { M.dataErr = true; });
    }).catch(function () { M.ug = false; });
  }
  function appRows(list, key, max, bytes) {
    return list.filter(function (a) { return a[key] > 0; }).sort(function (a, b) { return b[key] - a[key]; }).slice(0, 8).map(function (a) {
      var val = bytes ? fmt(a.v) : dur(a.v);
      return '<div class="arow">' + (a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="noic">📦</span>') + '<div style="flex:1;min-width:0"><b class="an">' + (a.label || a.pkg) + '</b><div class="mbar"><i style="width:' + Math.max(3, Math.round(a[key] / max * 100)) + '%"></i></div></div><span class="av">' + val + '</span></div>';
    }).join('');
  }
  function vMonitor(soft) {
    setTop(T('فون مانیٹر', 'Phone monitor'));
    var M = S.mon = S.mon || {};
    if (!soft) { clearMon(); loadMon(true); monTimer = setInterval(function () { if (S.view !== 'monitor') return clearMon(); loadMon(false); }, 5000); }
    if (!soft || !$('#monroot')) { $('#body').innerHTML = '<div id="monroot"></div>'; }
    var s = M.snap, h = '';
    if (!s) { $('#monroot').innerHTML = '<div class="card center"><div class="spin"></div></div>'; return; }
    var b = s.battery || {}, lvl = b.level || 0, hist = recordBat(lvl); if (M.hist && M.hist.length > 1) hist = M.hist;
    var plug = { ac: tt('چارجر', 'AC charger'), usb: 'USB', wireless: tt('وائرلیس', 'Wireless'), none: '' }[b.plug] || '';
    var healthN = { 2: ['اچھی', 'Good'], 3: ['زیادہ گرم', 'Overheated'], 4: ['خراب', 'Dead'], 5: ['زیادہ وولٹیج', 'Over voltage'], 6: ['خرابی', 'Failure'], 7: ['بہت ٹھنڈی', 'Cold'] }[b.health] || ['نامعلوم', 'Unknown'];
    var mA = b.currentUa ? Math.round(Math.abs(b.currentUa) / (Math.abs(b.currentUa) > 20000 ? 1000 : 1)) : 0, cap = b.chargeUah ? Math.round(b.chargeUah / 1000) : 0, left = '';
    if (b.charging && b.chargeMs) left = dur(b.chargeMs) + ' ' + tt('میں مکمل چارج', 'to full');
    else if (!b.charging && cap && mA > 20) left = '≈ ' + dur(cap / mA * 3600000) + ' ' + tt('باقی', 'left');
    var hot = b.temp >= 40, col = lvl <= 15 && !b.charging ? 'var(--red)' : 'var(--acc)';
    h += '<div class="hero" style="margin-top:6px"><div class="ring"><svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--line)" stroke-width="3.4"/><circle cx="18" cy="18" r="15.5" fill="none" stroke="' + col + '" stroke-width="3.4" stroke-linecap="round" stroke-dasharray="' + (Math.max(2, lvl) * 0.97).toFixed(1) + ' 100"/></svg><div>' + lvl + '%</div></div><div style="flex:1"><div class="k">' + (b.full ? T('بیٹری مکمل', 'Fully charged') : b.charging ? T('چارج ہو رہی ہے ⚡', 'Charging ⚡') : T('بیٹری', 'Battery')) + '</div><div style="margin-top:4px;font-size:15px">' + (left || '') + '</div><div class="mut" style="font-size:12.5px">' + plug + (b.saver ? ' · ' + tt('بیٹری سیور آن', 'Battery saver on') : '') + '</div></div></div>';
    h += '<div class="card"><div class="kv"><span>' + tt('درجہ حرارت', 'Temperature') + '</span><b style="color:' + (hot ? 'var(--red)' : 'inherit') + '">' + (b.temp != null ? b.temp.toFixed(1) + ' °C' : '–') + (hot ? ' ⚠' : '') + '</b></div>' +
      '<div class="kv"><span>' + tt('بیٹری کی صحت', 'Health') + '</span><b>' + tt(healthN[0], healthN[1]) + '</b></div>' +
      '<div class="kv"><span>' + tt('وولٹیج', 'Voltage') + '</span><b>' + (b.voltage ? (b.voltage / 1000).toFixed(2) + ' V' : '–') + '</b></div>' +
      (mA ? '<div class="kv"><span>' + tt(b.charging ? 'چارجنگ کرنٹ' : 'استعمال کا کرنٹ', b.charging ? 'Charging current' : 'Draw') + '</span><b>' + mA + ' mA</b></div>' : '') +
      (cap ? '<div class="kv"><span>' + tt('موجودہ چارج', 'Charge now') + '</span><b>' + cap + ' mAh</b></div>' : '') +
      (b.tech ? '<div class="kv"><span>' + tt('ٹیکنالوجی', 'Technology') + '</span><b>' + b.tech + '</b></div>' : '') +
      '<div class="sec" style="margin:12px 0 0">' + tt('بیٹری کی ہسٹری', 'BATTERY HISTORY') + '</div>' + spark(hist) + '</div>';
    var mo = M.mon;
    if (mo) {
      var chips = function (key, flag, vals, unit) {
        return '<div class="chips">' + vals.map(function (v) { var on = mo[flag] && mo[key] === v; return '<button class="chip' + (on ? ' on' : '') + '" data-mset="' + key + ':' + v + '">' + v + unit + '</button>'; }).join('') + '<button class="chip' + (!mo[flag] ? ' on' : '') + '" data-mset="' + flag + ':0">' + tt('بند', 'Off') + '</button></div>';
      };
      h += '<div class="sec">' + tt('الرٹس اور پس منظر نگرانی', 'ALERTS AND BACKGROUND MONITORING') + '</div><div class="card"><div class="kv"><span>' + tt('نگرانی', 'Monitoring') + '</span><b style="color:' + (mo.on ? 'var(--acc)' : 'var(--mut)') + '">' + (mo.on ? tt('آن', 'ON') : tt('بند', 'OFF')) + '</b></div>' +
        '<p class="mut" style="font-size:12.5px;margin:6px 0">' + tt('آن ہونے پر ایپ بند ہونے کے بعد بھی بیٹری کی ہسٹری بنتی رہتی ہے اور الرٹ آتے ہیں۔ اوپر ایک چھوٹا نوٹیفکیشن مستقل رہتا ہے۔', 'When on, battery history keeps recording and alerts arrive even when the app is closed. A small notification stays visible.') + '</p>' +
        '<div class="sec" style="margin:10px 0 4px">' + tt('چارج کی حد (چارجر ہٹانے کی یاد دہانی)', 'CHARGE LIMIT (REMIND ME TO UNPLUG)') + '</div>' + chips('limit', 'aLimit', [70, 80, 90, 100], '%') +
        '<div class="sec" style="margin:10px 0 4px">' + tt('کم بیٹری کا الرٹ', 'LOW BATTERY ALERT') + '</div>' + chips('low', 'aLow', [10, 15, 20, 30], '%') +
        '<div class="sec" style="margin:10px 0 4px">' + tt('گرمی کا الرٹ', 'HEAT ALERT') + '</div>' + chips('hot', 'aHot', [40, 42, 45, 48], '°') +
        '<button class="btn" id="monToggle">' + (mo.on ? T('نگرانی بند کریں', 'Stop monitoring') : T('نگرانی شروع کریں', 'Start monitoring')) + '</button>' +
        (mo.on ? '<button class="btn" id="monOpt" style="background:var(--card2);color:var(--text);box-shadow:none;border:1px solid var(--line);min-height:44px;font-size:15px">' + T('اگر الرٹ رک جائیں تو یہاں سے بیٹری آپٹمائزیشن بند کریں', 'If alerts stop, turn off battery optimisation') + '</button>' : '') + '</div>';
    }
    var ru = s.ram.total - s.ram.avail, rp = Math.round(ru / s.ram.total * 100), su = s.storage.total - s.storage.free, sp = s.storage.total ? Math.round(su / s.storage.total * 100) : 0;
    h += '<div class="sec">' + tt('میموری اور اسٹوریج', 'MEMORY AND STORAGE') + '</div><div class="card"><div class="kv"><span>RAM</span><b>' + fmt(ru) + ' / ' + fmt(s.ram.total) + ' (' + rp + '%)</b></div><div class="mbar"><i style="width:' + rp + '%' + (rp > 85 ? ';background:var(--red)' : '') + '"></i></div>' +
      '<div class="kv" style="margin-top:12px"><span>' + tt('اسٹوریج', 'Storage') + '</span><b>' + fmt(su) + ' / ' + fmt(s.storage.total) + ' (' + sp + '%)</b></div><div class="mbar"><i style="width:' + sp + '%' + (sp > 90 ? ';background:var(--red)' : '') + '"></i></div></div>';
    var d = s.device, up = dur(d.uptime);
    h += '<div class="sec">' + tt('فون کی معلومات', 'DEVICE') + '</div><div class="card"><div class="kv"><span>' + tt('ماڈل', 'Model') + '</span><b>' + (d.brand ? d.brand.charAt(0).toUpperCase() + d.brand.slice(1) + ' ' : '') + d.model + '</b></div><div class="kv"><span>Android</span><b>' + d.android + ' (API ' + d.sdk + ')</b></div><div class="kv"><span>' + tt('پروسیسر کور', 'CPU cores') + '</span><b>' + d.cores + (d.abi ? ' · ' + d.abi : '') + '</b></div><div class="kv"><span>' + tt('آن ہوئے کو', 'Uptime') + '</span><b>' + up + '</b></div><div class="kv"><span>' + tt('نیٹ ورک', 'Network') + '</span><b>' + ({ wifi: 'Wi-Fi', mobile: tt('موبائل ڈیٹا', 'Mobile data'), none: tt('بند', 'Offline'), other: tt('دیگر', 'Other') }[s.net] || '–') + '</b></div></div>';
    h += '<div class="sec">' + tt('ایپس کا استعمال', 'APP USAGE') + '</div>';
    if (M.ug === false) {
      h += '<div class="card center"><div style="font-size:40px">📊</div><h2 style="font-size:18px">' + T('Usage access کی اجازت', 'Usage access needed') + '</h2><p class="mut" style="margin-top:6px">' + tt('اسکرین ٹائم اور ڈیٹا کا استعمال دیکھنے کے لیے کھلنے والی سکرین میں Cleanova کو آن کریں، پھر واپس آ جائیں۔ یہ معلومات فون سے باہر نہیں جاتیں۔', 'To see screen time and data use, turn Cleanova on in the screen that opens, then come back. This data never leaves your phone.') + '</p><button class="btn" id="uallow">' + T('اجازت دیں', 'Grant access') + '</button>' +
        '<div class="card" style="text-align:start;margin-top:12px;background:var(--card2)"><b style="font-size:14px">' + tt('اگر "App was denied access" لکھا آئے', 'If you see "App was denied access"') + '</b><p class="mut" style="font-size:13px;margin-top:6px;line-height:1.8">' + tt('یہ اینڈرائیڈ 13+ کا حفاظتی اصول ہے (APK سے انسٹال کی گئی ایپس کے لیے)۔<br>1) نیچے بٹن سے App info کھولیں۔<br>2) اوپر دائیں کونے میں ⋮ (تین نقطے) دبائیں۔<br>3) "Allow restricted settings" چنیں۔<br>4) واپس آ کر دوبارہ "اجازت دیں" دبائیں۔', 'This is an Android 13+ safety rule for apps installed from an APK.<br>1) Open App info with the button below.<br>2) Tap ⋮ (three dots) at the top right.<br>3) Choose "Allow restricted settings".<br>4) Come back and tap "Grant access" again.') + '</p><button class="btn" id="uinfo" style="min-height:44px;font-size:15px;background:var(--card);color:var(--text);box-shadow:none;border:1px solid var(--line)">' + T('App info کھولیں', 'Open App info') + '</button></div></div>';
    } else if (M.usage) {
      var u = M.usage, tot = 0; u.days.forEach(function (x) { tot += x; });
      h += '<div class="card"><div class="kv"><span>' + tt('آج کا اسکرین ٹائم', 'Screen time today') + '</span><b style="font-size:18px;color:var(--acc)">' + dur(u.days[6]) + '</b></div><div class="kv"><span>' + tt('روزانہ اوسط (7 دن)', 'Daily average (7 days)') + '</span><b>' + dur(tot / 7) + '</b></div>' + (u.unlocks ? '<div class="kv"><span>' + tt('آج فون کھولا', 'Unlocks today') + '</span><b>' + u.unlocks + '</b></div>' : '') + monBars(u.days, function (v) { return Math.round(v / 360000) / 10 + 'h'; }) + '</div>';
      var mx = Math.max.apply(null, u.apps.map(function (a) { return a.week; }).concat([1]));
      h += '<div class="card"><div class="sec" style="margin:0 0 8px">' + tt('سب سے زیادہ استعمال (7 دن)', 'MOST USED (7 DAYS)') + '</div>' + appRows(u.apps.map(function (a) { return { label: a.label, pkg: a.pkg, icon: a.icon, week: a.week, v: a.week }; }), 'week', mx) + '</div>';
    } else if (M.usageErr) { h += '<div class="card mut">' + tt('استعمال کی معلومات نہیں مل سکیں۔', 'Could not read app usage.') + '</div>'; }
    else if (M.ug) { h += '<div class="card center"><div class="spin"></div></div>'; }
    if (M.ug && M.unused && M.unused.apps && M.unused.apps.length) {
      h += '<div class="sec">' + tt('ایپس جو 30 دن سے نہیں کھولیں', 'APPS NOT OPENED FOR 30+ DAYS') + '</div><div class="card">' + M.unused.apps.map(function (a) {
        return '<div class="arow">' + (a.icon ? '<img src="' + a.icon + '" alt="">' : '<span class="noic">📦</span>') + '<div style="flex:1;min-width:0"><b class="an">' + (a.label || a.pkg) + '</b><span class="mut" style="font-size:11.5px">' + (a.idleDays >= 9999 ? tt('کبھی نہیں کھولی', 'never opened') : a.idleDays + ' ' + tt('دن', 'days')) + ' · ' + fmt(a.size) + '</span></div><button class="chip" data-un="' + a.pkg + '">' + tt('ہٹائیں', 'Remove') + '</button></div>';
      }).join('') + '<p class="mut" style="font-size:12px;margin-top:8px">' + tt('ہٹانے سے پہلے اینڈرائیڈ آپ سے تصدیق مانگے گا۔', 'Android will ask you to confirm before removing.') + '</p></div>';
    }
    if (M.ug && M.data) {
      var dd = M.data, wt = 0, mt = 0; dd.wifi.forEach(function (x) { wt += x; }); dd.mobile.forEach(function (x) { mt += x; });
      var both = dd.wifi.map(function (x, i) { return x + dd.mobile[i]; });
      h += '<div class="sec">' + tt('ڈیٹا کا استعمال', 'DATA USAGE') + '</div><div class="card"><div class="kv"><span>' + tt('آج Wi-Fi', 'Wi-Fi today') + '</span><b>' + fmt(dd.wifi[6]) + '</b></div><div class="kv"><span>' + tt('آج موبائل ڈیٹا', 'Mobile data today') + '</span><b>' + fmt(dd.mobile[6]) + '</b></div><div class="kv"><span>' + tt('7 دن: Wi-Fi / موبائل', '7 days: Wi-Fi / mobile') + '</span><b>' + fmt(wt) + ' / ' + fmt(mt) + '</b></div>' + monBars(both, function (v) { return fmt(v).replace(' ', ''); }, 'var(--acc2)') + '</div>';
      var dm = Math.max.apply(null, dd.apps.map(function (a) { return a.week; }).concat([1]));
      h += '<div class="card"><div class="sec" style="margin:0 0 8px">' + tt('سب سے زیادہ ڈیٹا (7 دن)', 'TOP DATA USERS (7 DAYS)') + '</div>' + appRows(dd.apps.map(function (a) { return { label: a.label, pkg: a.pkg, icon: a.icon, week: a.week, v: a.week }; }), 'week', dm, true) + '</div>';
    }
    h += '<p class="mut" style="font-size:12px;margin:14px 4px">' + tt('نوٹ: اعداد و شمار اینڈرائیڈ سسٹم سے لیے جاتے ہیں، کچھ فونز پر کچھ قدریں دستیاب نہیں ہوتیں۔', 'Note: values come from Android and some phones do not report every reading.') + '</p>' + footer();
    $('#monroot').innerHTML = h;
    [].forEach.call(document.querySelectorAll('[data-mset]'), function (b) {
      b.onclick = function () {
        var p = b.dataset.mset.split(':'), o = {};
        if (p[0].charAt(0) === 'a') o[p[0]] = false; else { o[p[0]] = +p[1]; o['a' + p[0].charAt(0).toUpperCase() + p[0].slice(1)] = true; }
        MP.monitorSet(o).then(function () { return MP.monitorStatus(); }).then(function (r) { M.mon = r; vMonitor(true); });
      };
    });
    var mt = $('#monToggle'); if (mt) mt.onclick = function () {
      if (M.mon.on) { MP.monitorStop().then(function () { M.mon.on = false; vMonitor(true); }); return; }
      var LN = Cap && Cap.Plugins && Cap.Plugins.LocalNotifications;
      Promise.resolve(LN && LN.requestPermissions ? LN.requestPermissions().catch(function () { return null; }) : null).then(function () { return MP.monitorStart(); }).then(function () { M.mon.on = true; vMonitor(true); toast('نگرانی شروع ہو گئی', 'Monitoring started'); }).catch(function (e) { toast('شروع نہیں ہو سکی', 'Could not start: ' + (e && e.message || e)); });
    };
    var mo2 = $('#monOpt'); if (mo2) mo2.onclick = function () { MP.batteryOptOpen().catch(function () { /* unavailable */ }); };
    [].forEach.call(document.querySelectorAll('[data-un]'), function (b) { b.onclick = function () { MP.uninstall({ pkg: b.dataset.un }).catch(function () { /* unavailable */ }); }; });
    var ui = $('#uinfo'); if (ui) ui.onclick = function () { MP.appInfoOpen().catch(function () { /* unavailable */ }); };
    var ua = $('#uallow'); if (ua) ua.onclick = function () { MP.usageRequest().catch(function () { /* settings unavailable */ }); };
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden && S.view === 'monitor' && S.mon && S.mon.ug === false) { S.mon.ug = undefined; vMonitor(); } });

  function vContacts() {
    setTop(T('ڈپلیکیٹ کانٹیکٹس', 'Duplicate contacts')); setBottom('');
    var c = S.ct = S.ct || { st: 'init', groups: [], sel: {}, act: 'merge' };
    if (c.st === 'init') {
      c.st = 'checking'; P.contactsStatus().then(function (r) { c.st = r && r.granted ? 'ready' : 'need'; if (S.view === 'contacts') vContacts(); }).catch(function () { c.st = 'need'; if (S.view === 'contacts') vContacts(); });
      $('#body').innerHTML = '<div class="card center"><div class="spin"></div></div>'; return;
    }
    if (c.st === 'checking' || c.st === 'working') { $('#body').innerHTML = '<div class="card center"><div class="spin"></div><h2 style="font-size:19px">' + T(c.st === 'working' ? 'کام جاری ہے…' : 'دیکھ رہا ہوں…', c.st === 'working' ? 'Working…' : 'Checking…') + '</h2></div>'; return; }
    if (c.st === 'need') {
      $('#body').innerHTML = '<div class="card center"><div style="font-size:50px">👥</div><h2 style="font-size:21px">' + T('کانٹیکٹس کی اجازت', 'Contacts permission') + '</h2><p class="mut" style="margin-top:8px">' + tt('ڈپلیکیٹ کانٹیکٹس ڈھونڈنے اور جوڑنے کے لیے کانٹیکٹس پڑھنے اور بدلنے کی اجازت چاہیے۔ سب کچھ آپ کے فون میں رہتا ہے، کچھ اپلوڈ نہیں ہوتا۔', 'To find and merge duplicate contacts, Cleanova needs permission to read and change contacts. Everything stays on your phone; nothing is uploaded.') + '</p><button class="btn" id="callow">' + T('اجازت دیں', 'Allow') + '</button></div>' + footer();
      $('#callow').onclick = function () { P.contactsRequest().then(function (r) { c.st = r && r.granted ? 'ready' : 'need'; if (!(r && r.granted)) toast('اجازت نہیں ملی', 'Permission not granted'); vContacts(); }).catch(function () { toast('اجازت نہیں ملی', 'Permission not granted'); }); };
      return;
    }
    if (c.st === 'ready') {
      $('#body').innerHTML = '<div class="card center"><div style="font-size:50px">👥</div><h2 style="font-size:21px">' + T('ڈپلیکیٹ کانٹیکٹس', 'Duplicate contacts') + '</h2><p class="mut" style="margin-top:8px">' + tt('ایک ہی نمبر یا ایک ہی نام کے کانٹیکٹس ڈھونڈے جائیں گے۔ کوئی تبدیلی آپ کی تصدیق کے بغیر نہیں ہو گی، اور تبدیلی سے پہلے سارے کانٹیکٹس کی بیک اپ فائل بنے گی۔', 'Finds contacts with the same number or name. Nothing changes without your confirmation, and a backup file of all contacts is saved before any change.') + '</p><button class="btn" id="cscan">' + T('ڈپلیکیٹ ڈھونڈیں', 'Find duplicates') + '</button></div>' + footer();
      $('#cscan').onclick = function () {
        c.st = 'working'; vContacts();
        P.contactsScan().then(function (r) {
          c.groups = r.groups || []; c.total = r.total || 0; c.sel = {};
          c.groups.forEach(function (g, i) { if (g.reason === 'number') c.sel[i] = 1; });
          c.st = 'list'; vContacts();
        }).catch(function (e) { c.st = 'ready'; vContacts(); toast('اسکین نہیں ہو سکا', 'Scan failed: ' + (e && e.message || e)); });
      };
      return;
    }
    if (c.st === 'result') {
      var m = c.result;
      $('#body').innerHTML = '<div class="card center"><div style="font-size:54px">✅</div><h2 style="font-size:21px">' + T(m.act === 'merge' ? m.n + ' گروپ جوڑ دیے گئے' : m.n + ' فالتو کانٹیکٹس ہٹا دیے گئے', m.act === 'merge' ? m.n + ' groups merged' : m.n + ' extra contacts removed') + '</h2>' +
        '<p class="mut" style="margin-top:8px">' + tt('بیک اپ فائل (' + m.count + ' کانٹیکٹس) یہاں محفوظ ہے:', 'Backup file (' + m.count + ' contacts) saved at:') + '</p><div class="pill" style="display:block;white-space:normal;word-break:break-all;margin-top:6px;text-align:start">' + esc(m.path.replace('/storage/emulated/0/', '')) + '</div>' +
        '<p class="mut" style="margin-top:10px">' + tt('اگر کچھ غلط ہو جائے تو فون کی Contacts ایپ کھولیں، Settings میں Import کا آپشن چنیں اور یہ .vcf فائل منتخب کریں۔', 'If anything goes wrong, open your phone\'s Contacts app, choose Import in its settings, and pick this .vcf file.') + '</p>' +
        '<button class="btn" id="cdone">' + T('ٹھیک ہے', 'Done') + '</button></div>' + footer();
      $('#cdone').onclick = function () { S.back = []; S.view = 'home'; render(); };
      return;
    }
    /* list */
    if (!c.groups.length) { $('#body').innerHTML = '<div class="card center"><div style="font-size:54px">✨</div><h2 style="font-size:21px">' + T('کوئی ڈپلیکیٹ نہیں ملا', 'No duplicate contacts') + '</h2><p class="mut">' + c.total + ' ' + tt('کانٹیکٹس دیکھے گئے', 'contacts checked') + '</p></div>' + footer(); return; }
    var h = '<div class="hero" style="display:block"><div class="k">' + T('ڈپلیکیٹ گروپ ملے', 'Duplicate groups found') + '</div><div class="big">' + c.groups.length + '</div><div class="k" style="font-size:12.5px">' + c.total + ' ' + tt('کانٹیکٹس میں سے', 'contacts checked') + '</div></div>' +
      '<div class="chips"><button class="chip' + (c.act === 'merge' ? ' on' : '') + '" data-act="merge">' + tt('جوڑیں (تجویز کردہ)', 'Merge (recommended)') + '</button><button class="chip' + (c.act === 'delete' ? ' on' : '') + '" data-act="delete">' + tt('فالتو ہٹائیں', 'Delete extra') + '</button></div>' +
      '<p class="mut" style="margin-top:8px">' + (c.act === 'merge' ? tt('جوڑنے سے سب نمبر ایک کانٹیکٹ میں آ جاتے ہیں، کچھ ضائع نہیں ہوتا۔', 'Merging puts all numbers into one contact; nothing is lost.') : tt('ہر گروپ میں سب سے زیادہ نمبروں والا رہے گا، باقی ہٹ جائیں گے۔', 'In each group the contact with the most numbers stays; the others are removed.')) + '</p>';
    c.groups.forEach(function (g, i) {
      h += '<div class="grp"><div class="hd"><span>' + (g.reason === 'number' ? tt('ایک ہی نمبر', 'Same number') : tt('ایک ہی نام، نمبر مختلف', 'Same name, different numbers')) + '</span><button class="sw" data-g="' + i + '" aria-pressed="' + !!c.sel[i] + '" aria-label="select"></button></div>';
      g.contacts.forEach(function (ct, k) {
        h += '<div class="row"><div class="t"><b>' + esc(ct.name || '—') + '</b><small class="e" style="display:block;direction:ltr;text-align:start">' + esc((ct.numbers || []).join(' · ')) + '</small></div>' + (c.act === 'delete' ? '<span class="pill' + (k === 0 ? ' a' : '') + '">' + (k === 0 ? tt('رکھیں ★', 'Keep ★') : tt('ہٹائیں', 'Remove')) + '</span>' : '') + '</div>';
      });
      h += '</div>';
    });
    $('#body').innerHTML = h + footer();
    [].forEach.call(document.querySelectorAll('[data-act]'), function (b) { b.onclick = function () { c.act = b.dataset.act; var y = $('#body').scrollTop; vContacts(); $('#body').scrollTop = y; }; });
    [].forEach.call(document.querySelectorAll('[data-g]'), function (b) { b.onclick = function () { var i = b.dataset.g; if (c.sel[i]) delete c.sel[i]; else c.sel[i] = 1; var y = $('#body').scrollTop; vContacts(); $('#body').scrollTop = y; }; });
    var n = Object.keys(c.sel).length;
    setBottom('<button class="btn" id="capply"' + (n ? '' : ' disabled') + '>' + T(c.act === 'merge' ? 'چنے ہوئے ' + n + ' گروپ جوڑیں' : 'چنے ہوئے ' + n + ' گروپ سے فالتو ہٹائیں', c.act === 'merge' ? 'Merge ' + n + ' selected groups' : 'Remove extras from ' + n + ' groups') + '</button>');
    $('#capply').onclick = confirmContacts;
  }
  function confirmContacts() {
    var c = S.ct, n = Object.keys(c.sel).length; if (!n) return;
    var m = $('#modal'); m.hidden = false;
    $('#sheet').innerHTML = '<h2 style="font-size:22px">' + T('تصدیق', 'Confirm') + '</h2><p style="margin-top:6px">' + tt(c.act === 'merge' ? n + ' گروپ کے کانٹیکٹس جوڑے جائیں گے۔' : n + ' گروپ میں سے فالتو کانٹیکٹس ہٹائے جائیں گے۔', c.act === 'merge' ? n + ' groups will be merged.' : 'Extra contacts in ' + n + ' groups will be removed.') + '</p>' +
      '<p class="mut">' + tt('پہلے سارے کانٹیکٹس کی بیک اپ فائل (.vcf) بنے گی۔', 'A backup file (.vcf) of all contacts is made first.') + '</p>' +
      '<button class="btn' + (c.act === 'delete' ? ' red' : '') + '" id="okc">' + T('ٹھیک ہے، شروع کریں', 'Yes, go ahead') + '</button><button class="btn o" id="noc">' + T('واپس جائیں', 'Cancel') + '</button>';
    $('#noc').onclick = function () { m.hidden = true; };
    $('#okc').onclick = function () { m.hidden = true; applyContacts(); };
  }
  function applyContacts() {
    var c = S.ct, idx = Object.keys(c.sel), act = c.act, bk;
    c.st = 'working'; setBottom(''); vContacts();
    P.contactsBackup().then(function (b) {
      bk = b;
      if (act === 'merge') return P.contactsMerge({ groups: idx.map(function (i) { return c.groups[i].contacts.map(function (x) { return x.id; }); }) }).then(function (r) { return r.merged || 0; });
      var ids = []; idx.forEach(function (i) { c.groups[i].contacts.slice(1).forEach(function (x) { ids.push(x.id); }); });
      return P.contactsDelete({ ids: ids }).then(function (r) { return r.deleted || 0; });
    }).then(function (n) {
      c.result = { act: act, n: n, path: bk.path, count: bk.count }; c.st = 'result'; vContacts();
    }).catch(function (e) { c.st = 'list'; vContacts(); toast('کام نہیں ہو سکا، کچھ نہیں بدلا', 'Failed, nothing was changed: ' + (e && e.message || e)); });
  }

  /* ---------- start ---------- */
  function withTimeout(promise, ms) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(new Error('timeout: native plugin did not answer in ' + ms / 1000 + 's')); }, ms);
      promise.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
  }
  var purged = false;
  function refreshStatus(quiet) {
    var call;
    try { call = withTimeout(P.status(), 5000); } catch (e) { call = Promise.reject(e); }
    return call.then(function (r) {
      S.granted = !!r.granted; S.free = r.free || 0; S.total = r.total || 0;
      if (S.granted && !purged) { purged = true; P.trashPurge({ days: PREF.trashDays }).catch(function () { /* ignore */ }); }
      if (!quiet) { if (S.granted && S.view === 'gate') S.view = 'home'; render(); }
    }).catch(function (e) { if (S.view === 'home') S.view = 'gate'; render(); if (window.cleanovaDiag) window.cleanovaDiag('status failed: ' + (e && (e.message || e)) + '\nCapacitor: ' + typeof window.Capacitor + ', native: ' + (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()) + ', plugin: ' + typeof P); });
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible' && (S.view === 'gate' || !S.total)) refreshStatus(); });
  CL.S = S; CL.PREF = PREF; CL.T = T; CL.tt = tt; CL.$ = $; CL.esc = esc; CL.store = store; CL.go = go; CL.goBack = goBack; CL.render = render; CL.setTop = setTop; CL.setBottom = setBottom; CL.footer = footer; CL.toast = toast; CL.fmt = fmt; CL.km = km; CL.dur = dur; CL.TP = TP; CL.MP = MP; CL.P = P; CL.ico = ico; CL.IC = IC; CL.LN = LN; CL.TAB_OF = TAB_OF; CL.applyLook = applyLook; CL.tclock = tclock; CL.setNav = setNav; CL.openTool = openTool;
  window.CLtest = CL;
  if (window.CLifeInit) window.CLifeInit(CL);
  window.cleanovaTest = { S: S, PREF: PREF, render: render, prepare: prepare, go: go };
  applyLook();
  refreshStatus();
  setTimeout(resumeScan, 1500);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) resumeScan(); });
})();
